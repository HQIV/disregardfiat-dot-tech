"""
S⁷ nuclear-torus perturbed Casimir energy (float mirror).

Lean:
  • ``Hqiv/Geometry/NuclearTorusPerturbation.lean``
  • ``Hqiv/Geometry/S7MetahorizonCasimir.lean``

Dimensionless ladder sums use octonion associator imprint on greedy ``occupationList``.
No eV anchors in src — surplus stays in λ-units (Lean ``bondHorizonSurplusDimless``).
"""

from __future__ import annotations

import math
from math import comb
from typing import Callable, Iterable, Sequence

Vec8 = list[float]

DEFAULT_UUD_ANGLES_RAD = (0.0, 2.0 * math.pi / 3.0, 4.0 * math.pi / 3.0)


def _eye8() -> list[list[float]]:
    return [[1.0 if i == j else 0.0 for j in range(8)] for i in range(8)]


def _mat_sum_scaled(mats: Sequence[Sequence[Sequence[float]]], coeffs: Sequence[float]) -> list[list[float]]:
    out = [[0.0] * 8 for _ in range(8)]
    for c, m in zip(coeffs, mats):
        for i in range(8):
            for j in range(8):
                out[i][j] += c * m[i][j]
    return out


def _matvec(m: Sequence[Sequence[float]], v: Vec8) -> Vec8:
    return [sum(m[i][j] * v[j] for j in range(8)) for i in range(8)]


def _L_octonion() -> list[list[list[float]]]:
    """``Hqiv/OctonionLeftMultiplication.lean`` row-major L(e_i)."""
    L1 = [
        [0, -1, 0, 0, 0, 0, 0, 0],
        [1, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, -1],
        [0, 0, 0, 0, 0, 0, 1, 0],
        [0, 0, 0, 0, 0, -1, 0, 0],
        [0, 0, 0, 0, 1, 0, 0, 0],
        [0, 0, 0, -1, 0, 0, 0, 0],
        [0, 0, 1, 0, 0, 0, 0, 0],
    ]
    L2 = [
        [0, 0, -1, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 1],
        [1, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, -1, 0],
        [0, 0, 0, 0, 0, 1, 0, 0],
        [0, 0, 0, 0, -1, 0, 0, 0],
        [0, 0, 0, 1, 0, 0, 0, 0],
        [0, -1, 0, 0, 0, 0, 0, 0],
    ]
    L3 = [
        [0, 0, 0, -1, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 1, 0],
        [0, 0, 0, 0, 0, -1, 0, 0],
        [1, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, -1],
        [0, 0, 1, 0, 0, 0, 0, 0],
        [0, -1, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 1, 0, 0, 0],
    ]
    L4 = [
        [0, 0, 0, 0, -1, 0, 0, 0],
        [0, 0, 0, 0, 0, 1, 0, 0],
        [0, 0, 0, 0, 0, 0, 1, 0],
        [0, 0, 0, 0, 0, 0, 0, 1],
        [1, 0, 0, 0, 0, 0, 0, 0],
        [0, -1, 0, 0, 0, 0, 0, 0],
        [0, 0, -1, 0, 0, 0, 0, 0],
        [0, 0, 0, -1, 0, 0, 0, 0],
    ]
    L5 = [
        [0, 0, 0, 0, 0, -1, 0, 0],
        [0, 0, 0, 0, -1, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, -1],
        [0, 0, 0, 0, 0, 0, 1, 0],
        [0, 1, 0, 0, 0, 0, 0, 0],
        [1, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, -1, 0, 0, 0, 0],
        [0, 0, 1, 0, 0, 0, 0, 0],
    ]
    L6 = [
        [0, 0, 0, 0, 0, 0, -1, 0],
        [0, 0, 0, 0, 0, 0, 0, 1],
        [0, 0, 0, 0, -1, 0, 0, 0],
        [0, 0, 0, 0, 0, -1, 0, 0],
        [0, 0, 1, 0, 0, 0, 0, 0],
        [0, 0, 0, 1, 0, 0, 0, 0],
        [1, 0, 0, 0, 0, 0, 0, 0],
        [0, -1, 0, 0, 0, 0, 0, 0],
    ]
    L7 = [
        [0, 0, 0, 0, 0, 0, 0, -1],
        [0, 0, 0, 0, 0, 0, -1, 0],
        [0, 0, 0, 0, 0, -1, 0, 0],
        [0, 0, 0, 0, -1, 0, 0, 0],
        [0, 0, 0, 1, 0, 0, 0, 0],
        [0, 0, 1, 0, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 0, 0, 0],
        [1, 0, 0, 0, 0, 0, 0, 0],
    ]
    return [L1, L2, L3, L4, L5, L6, L7]


_L_STORE = _L_octonion()


def left_mul_vec(x: Vec8, y: Vec8) -> Vec8:
    coeffs = [x[0]] + [x[i] for i in range(1, 8)]
    lx = _mat_sum_scaled(_L_STORE, coeffs[1:])
    for i in range(8):
        for j in range(8):
            lx[i][j] += coeffs[0] * (1.0 if i == j else 0.0)
    return _matvec(lx, y)


def octonion_associator_norm_sq(x: Vec8, y: Vec8, z: Vec8) -> float:
    xy_z = left_mul_vec(left_mul_vec(x, y), z)
    x_yz = left_mul_vec(x, left_mul_vec(y, z))
    return sum((xy_z[i] - x_yz[i]) ** 2 for i in range(8))


def spherical_harmonic_dim_s7(ell: int) -> int:
    return (2 * ell + 6) * comb(ell + 5, 5) // 6


def laplace_beltrami_eigenvalue_nat(ell: int) -> int:
    return ell * (ell + 6)


def fill_lambda_sum(remaining: int, ell: int, acc: int) -> int:
    if remaining == 0:
        return acc
    rem = remaining - 1
    d = spherical_harmonic_dim_s7(ell)
    if rem + 1 <= d:
        return acc + (rem + 1) * laplace_beltrami_eigenvalue_nat(ell)
    return fill_lambda_sum(rem + 1 - d, ell + 1, acc + d * laplace_beltrami_eigenvalue_nat(ell))


def occupation_list(n: int) -> list[int]:
    def fill(rem: int, ell: int, acc: list[int]) -> list[int]:
        if rem == 0:
            return list(reversed(acc))
        d = spherical_harmonic_dim_s7(ell)
        if rem <= d:
            return list(reversed([ell] * rem + acc))
        return fill(rem - d, ell + 1, [ell] * d + acc)

    return fill(n, 0, [])


def nuclear_torus_f(angles: tuple[float, float, float]) -> Vec8:
    t0, _, _ = angles
    v = [0.0] * 8
    v[1] = math.cos(t0)
    v[2] = math.sin(t0)
    return v


def nuclear_torus_x(angles: tuple[float, float, float]) -> Vec8:
    _, t1, _ = angles
    v = [0.0] * 8
    v[3] = math.cos(t1)
    v[4] = math.sin(t1)
    return v


def nuclear_torus_l(angles: tuple[float, float, float]) -> Vec8:
    _, _, t2 = angles
    v = [0.0] * 8
    v[5] = math.cos(t2)
    v[6] = math.sin(t2)
    return v


def associator_perturbation(ell: int, angles: tuple[float, float, float] = DEFAULT_UUD_ANGLES_RAD) -> float:
    f = nuclear_torus_f(angles)
    x = nuclear_torus_x(angles)
    l = nuclear_torus_l(angles)
    return float(ell) * octonion_associator_norm_sq(f, x, l)


def noninteracting_fermion_lambda_sum(n: int) -> int:
    return fill_lambda_sum(n, 0, 0)


def perturbed_casimir_energy(
    n: int,
    angles: tuple[float, float, float] = DEFAULT_UUD_ANGLES_RAD,
) -> float:
    """Lean ``perturbedCasimirEnergy`` (dimensionless λ-units)."""
    base = float(noninteracting_fermion_lambda_sum(n))
    occ = occupation_list(n)
    corr = sum(associator_perturbation(ell, angles) for ell in occ)
    return base + corr


def casimir_rows_for_kept_j(
    kept_j: Iterable[int],
    *,
    electron_count_for_j: Callable[[int], int] | None = None,
    angles: tuple[float, float, float] = DEFAULT_UUD_ANGLES_RAD,
) -> list[dict[str, float | int]]:
    if electron_count_for_j is None:

        def _default(j: int) -> int:
            return min(int(j) + 1, 256)

        electron_count_for_j = _default

    rows: list[dict[str, float | int]] = []
    for j in sorted(set(int(x) for x in kept_j)):
        n = int(electron_count_for_j(j))
        if n < 0:
            continue
        rows.append(
            {
                "j": j,
                "N_electrons": n,
                "noninteracting_lambda_sum": noninteracting_fermion_lambda_sum(n),
                "perturbed_casimir_energy_dimless": perturbed_casimir_energy(n, angles),
            }
        )
    return rows
