"""
pyhqiv

Fresh package root for the first-principles rebuild of the HQIV source tree.
The pre-reset implementation has been preserved in `bak/`, and the legacy
public surface has been recorded in `docs/legacy_api_inventory.md`.

Current rebuild status:

- `pyhqiv.lightcone` mirrors the discrete light-cone combinatorics.
- `pyhqiv.auxiliary_field` builds the phi/T ladder on top of that.
- `pyhqiv.metric` adds the HQVM lapse and homogeneous dynamics layer.
- `pyhqiv.modified_maxwell` adds the O/H Maxwell scaffold and tipping angle.
- `pyhqiv.fluid` adds the HQIV modified-fluid closure (`f`, `g_vac`, `ν_eddy`; see `AGENTS/FLUID_OMAXWELL_ROADMAP.md`).
- `pyhqiv.forces` adds the force-sector selector and unit conversions.
- `pyhqiv.now` provides a preliminary present-day bundle.
- `pyhqiv.spherical_harmonics` provides ``Y_ℓ^m`` and ``S²`` Laplace eigenvalues (SciPy).
- `pyhqiv.isotope_ladder` composes network masses, angular/rotational scaffolds, decay Q-values, and barns.
- `pyhqiv.hqiv_nuclei` mirrors ``HQIVNuclei.lean`` (Casimir energy, Fresnel caustics, constructive isotope ladder, deuteron scale).
- `pyhqiv.quantum_optics` mirrors ``Hqiv.QuantumOptics.HorizonQED`` (shell ladder frequencies, QED prefactors, Pauli/JC algebra).
- `pyhqiv.ins_dsf_simulator` provides small-chain exact **dense expm** vs **Trotter** INS / DSF paths (arXiv:2603.15608-style kick + spectrum) for side-by-side benchmarking.
- `pyhqiv.benchmark_osh_vs_dense` mirrors ``HQIV_LEAN/scripts/benchmark_protein_osh_vs_dense.py`` (**dense vs sparse** protein-style mean-field workload from the octonion light-cone paper). Lean + TeX: **HQIV_LEAN** (e.g. ``~/Repos/HQIV_LEAN``).
- `pyhqiv.sm_embedding_sim` implements ``Hqiv.Algebra.SMEmbedding`` quantum numbers and optional **U(1)/SU(2)ₗ** dynamics on ``ℂ⁸`` (SU(2) from ``HQVM.matrices.OctonionHQIVAlgebra`` when ``HQIV`` is on ``PYTHONPATH``).
- `pyhqiv.state` provides **HQIVState** (unified shell / curvature / metric / witnesses / optional carrier).
- `pyhqiv.carrier` provides **So8Carrier** and SO(8) Hamiltonian assembly; certified generators load from Lean or packaged ``so8_generators.json``.
- `pyhqiv.regimes` offers thin **galactic**, **black-hole / horizon**, and **quantum** façades over existing modules (Lean citations in each file).
"""

from pyhqiv.action import (
    ActionSnapshot,
    build_action_snapshot,
    friedmann_from_action_equivalence_holds,
    s_hqvm_grav,
    s_hqvm_grav_zero_holds,
)
from pyhqiv.auxiliary_field import (
    phase_lift_coeff_real,
    phi_of_real_shell,
    phi_of_shell,
    phi_of_temperature,
    phi_temperature_coefficient,
    shell_mass_geometry_factor,
    shell_shape_real,
    shell_temperature,
    shell_temperature_factor,
    t_pl_natural,
)
from pyhqiv.benchmark_osh_vs_dense import (
    BenchCase as ProteinOshBenchCase,
)
from pyhqiv.benchmark_osh_vs_dense import (
    format_table_row as protein_osh_benchmark_format_row,
)
from pyhqiv.benchmark_osh_vs_dense import (
    paper_table_cases as protein_osh_benchmark_paper_cases,
)
from pyhqiv.benchmark_osh_vs_dense import (
    run_case as protein_osh_benchmark_run_case,
)
from pyhqiv.benchmark_osh_vs_dense import (
    run_paper_table as protein_osh_benchmark_run_paper_table,
)
from pyhqiv.carrier import So8Carrier, hamiltonian_from_so8_coeffs
from pyhqiv.conservations import (
    ConservationCheck,
    build_conservation_check,
    lapse_forces_time_angle_term,
    phase_conservation_numeric,
    structure_from_o_dim,
)
from pyhqiv.derived_gauge_report import (
    DERIVED_KEYS,
    derived_gauge_outputs,
    verify_pure_derived_keys_only,
)
from pyhqiv.derived_nucleon_report import (
    DERIVED_NUCLEON_KEYS,
    derived_nucleon_outputs,
    format_nucleon_report,
    verify_no_missing_keys,
)
from pyhqiv.fluid import (
    PlasmaFluidClosureHypothesis,
    eddy_viscosity,
    f_inertia,
    g_vac_vector,
    modified_momentum_rhs,
)
from pyhqiv.forces import (
    ForceSector,
    UnitSystem,
    ValueInUnits,
    c_si,
    e_field_natural_to_si,
    emergent_maxwell_inhomogeneous_o_metric,
    emergent_maxwell_inhomogeneous_o_si,
    energy_natural_to_si_j,
    force_natural_to_si,
    g_si,
    hbar_si,
    in_metric,
    in_si,
    length_natural_to_si,
    o_component_to_sector,
    time_axis,
    time_natural_to_si,
)
from pyhqiv.gr_from_maxwell import (
    hqvm_friedmann_power_residual,
    o_maxwell_determines_hqvm_gr_homogeneous_equivalence,
)
from pyhqiv.hqiv_nuclei import (
    SPECTRA_DEUTERON_BINDING_MEV,
    Nucleus,
    casimir_energy_surface,
    deuteron_binding_scale,
    ladder_path_from_ZN,
    make_nucleus,
    spherical_harmonic_cumulative_count,
    valley_count_from_A,
)
from pyhqiv.ins_dsf_simulator import (
    INSXxzDenseVsTrotter,
    INSXxzResult,
    apply_two_qubit_unitary_state,
    benchmark_ins_xxz_dense_vs_trotter,
    center_site_index,
    rgf_to_spectral_mirror_avg,
    simulate_xxz_rgf_center_kick,
    simulate_xxz_rgf_center_kick_trotter,
    spectrum_metrics_mse_wasserstein,
    xxz_hamiltonian_open_chain,
    xxz_nnn_hamiltonian_open_chain,
)
from pyhqiv.isotope_ladder import (
    DecayMode,
    DecayStep,
    IsotopeLadderConfig,
    IsotopeState,
    beta_half_life_s,
    cross_section_geometric_barns,
    cross_section_geometric_isotope_barns,
    enumerate_decay_steps,
    exoergic_decay_steps,
    gamma_half_life_proxy_s,
    nuclear_binding_energy_mev,
    nucleus_mass_mev,
    rotational_excitation_mev,
)
from pyhqiv.lightcone import (
    ALPHA_EXACT,
    alpha,
    available_modes,
    cube_axes,
    cube_directions,
    cumulative_lattice_simplex_count,
    curvature_density,
    curvature_integral,
    curvature_norm_combinatorial,
    delta_e,
    lattice_simplex_count,
    lattice_step_count,
    new_modes,
    octonion_imaginary_dim,
    omega_k_at_horizon,
    omega_k_partial,
    qcd_shell,
    reference_m,
    shell_shape,
    signs_per_axis,
    unit_cube_half_diagonal,
    x_over_theta_from_horizons,
)
from pyhqiv.metric import (
    HQVMMetricSnapshot,
    build_metric_snapshot,
    friedmann_lhs,
    friedmann_rhs,
    g0,
    g_eff,
    gamma_hqiv,
    h0,
    h_of_phi,
    hqvm_friedmann_holds,
    hqvm_friedmann_residual,
    hqvm_g_tt,
    hqvm_lapse,
    hqvm_spatial_coeff,
    rho_total,
    three_minus_gamma,
    time_angle,
    two_pi,
)
from pyhqiv.modified_maxwell import (
    charge_conservation_o,
    classic_maxwell_inhomogeneous,
    current_o,
    delta_theta_prime,
    div_mu,
    emergent_maxwell_inhomogeneous_h,
    emergent_maxwell_inhomogeneous_o,
    g_rr,
    grad_phi,
    horizon_quarter_period,
    in_h,
    maxwell3d_curl_b_minus_dedt,
    maxwell3d_div_e,
    spatial_indices,
)
from pyhqiv.now import (
    PreliminaryNow,
    TemperatureWitness,
    age_ratio_at_now,
    age_ratio_homogeneous,
    apparent_age,
    build_preliminary_now,
    build_temperature_witness,
    h0_ref,
    now_condition,
    shell_index_for_temperature,
    temperature_from_shell_index,
    wall_clock_age_homogeneous,
)
from pyhqiv.now_setters import (
    LegacyNowAnchorError,
    NowGeometry,
    active_slice,
    m_now,
    now_geometry,
    now_set_from_electron_horizon,
    nowSetter,
    rescale_geometry,
)
from pyhqiv.omaxwell_couplings import (
    alpha_eff_at_shell,
    alpha_eff_from_phi,
    alpha_gut,
    coulomb_strength_shell,
    expected_ground_energy_at_shell,
    one_over_alpha_eff,
)
from pyhqiv.orbital import (
    hqiv_flyby_inertia_screen,
    hqiv_galaxy_rotation_point,
    hqiv_inertia_factor,
    rindler_denominator,
)
from pyhqiv.quantum_lean_backing import (
    DEFAULT_QUANTUM_SPECS,
    LeanSymbolSpec,
    quantum_lean_backing_ok,
    validate_quantum_lean_backing,
)
from pyhqiv.quantum_mechanics import (
    Operator,
    Wavefunction,
    coulomb_potential,
    expected_ground_energy_at_shell,
    expected_ground_energy_shell,
    lapse_corrected_hamiltonian,
    lapse_factor,
    satisfies_lapse_corrected_schrodinger_residual,
    satisfies_time_dependent_schrodinger_residual,
    shell_coulomb_strength,
)

# vacuum zero point matching paper script for CC solution (finite modes vs QFT disaster)
from pyhqiv.quantum_optics.horizon_qed import vacuum_zero_point_natural
from pyhqiv.quantum_oracles import (
    GroverResult,
    OraclePredicate,
    PeriodFindingResult,
    estimate_period_from_peaks,
    hidden_tag_of,
    optimal_grover_iterations,
    oshoracle_grover_search,
    oshoracle_period_find,
    oshoracle_period_find_quantum,
    period_probability_distribution,
    period_support,
)
from pyhqiv.quantum_simulator import (
    Circuit,
    ComplexArray,
    Gates,
    NoiseModel,
    QuantumState,
    RunResult,
    ValueWithError,
    run_circuit,
)
from pyhqiv.sm_embedding import (
    SMLabel,
    sm_generation_index,
    sm_generation_offset,
    sm_hypercharge_weight,
    sm_sector_multiplicity,
)
from pyhqiv.sm_embedding_sim import (
    HYPERCHARGE_Y2 as sm_hypercharge_y2_table,
)
from pyhqiv.sm_embedding_sim import (
    Su2Generators as SM_SU2_Generators,
)
from pyhqiv.sm_embedding_sim import (
    evolve_su2 as sm_evolve_su2_on_8s,
)
from pyhqiv.sm_embedding_sim import (
    evolve_u1_hypercharge_sm_basis as sm_evolve_u1_hypercharge_8s,
)
from pyhqiv.sm_embedding_sim import (
    hypercharge_eigenvalue as sm_hypercharge_eigenvalue_fin8,
)
from pyhqiv.sm_embedding_sim import (
    su2_l_generators_from_octonion as sm_su2_l_generators_from_octonion,
)
from pyhqiv.sm_gr_unification import (
    M_Pl_natural,
    M_Z_natural,
    SMConstantsAtNow,
    alpha_EM_at_MZ,
    alpha_s_at_MZ,
    m_electron_natural,
    m_neutron_MeV_central,
    m_proton_MeV_central,
    one_over_alpha_EM_at_MZ,
    sin2thetaW_at_MZ,
    sm_constants_at_now,
)
from pyhqiv.sm_mass_ladder import (
    electron_geometry_factor,
    natural_mass_to_eV,
    sm_mass_from_geometry,
    sm_mass_shell_real,
    sm_masses_from_geometry_at_default_now,
    sm_masses_from_geometry_eV_at_default_now,
)
from pyhqiv.so8_generators import (
    So8Generators,
    dump_so8_generators_json,
    lie_bracket,
    load_so8_generators,
    load_so8_generators_auto,
    load_so8_generators_from_json,
    load_so8_generators_from_packaged_json,
    so8_tensor_sha256_hex,
    upper_triangle_coord,
)
from pyhqiv.spherical_harmonics import (
    laplace_beltrami_eigenvalue_S2,
    real_basis_dimension,
    spherical_harmonic_real_basis_matrix,
    spherical_harmonic_Y,
    spherical_harmonic_Y_real,
)
from pyhqiv.spin_statistics import (
    ResonanceTimes,
    SpinClass,
    build_resonance_times,
    exchange_phase_identical,
    hbar_MeV_s,
    resonance_half_life,
    resonance_lifetime,
    spin_statistics_exchange_sign_matches_two_pi,
    two_pi_phase,
)
from pyhqiv.state import HQIVState
from pyhqiv.thermo import (
    TESTABLE_PREDICTIONS,
    HQIVThermoSystem,
    PhaseDiagramGenerator,
    allotrope_theta_modifier,
    compute_free_energy,
    hqiv_answer_thermo,
    molar_mass_from_Z,
)
from pyhqiv.thermodynamic_fundamentals import (
    clausius_equality_proxy_power_form,
    clausius_residual_proxy,
    entropy_increment_per_shell,
    entropy_production_proxy,
    equilibrium_rho_total_for_phi,
    horizon_entropy_counting,
    local_equilibrium_proxy,
    second_law_arrow_holds,
    temperature_at_shell,
)

__all__ = [
    "ALPHA_EXACT",
    "ForceSector",
    "HQVMMetricSnapshot",
    "ActionSnapshot",
    "PreliminaryNow",
    "ConservationCheck",
    "TemperatureWitness",
    "UnitSystem",
    "ValueInUnits",
    "clausius_equality_proxy_power_form",
    "clausius_residual_proxy",
    "age_ratio_at_now",
    "age_ratio_homogeneous",
    "alpha",
    "apparent_age",
    "available_modes",
    "build_metric_snapshot",
    "build_preliminary_now",
    "build_temperature_witness",
    "c_si",
    "charge_conservation_o",
    "classic_maxwell_inhomogeneous",
    "cube_axes",
    "cube_directions",
    "current_o",
    "curvature_density",
    "curvature_integral",
    "curvature_norm_combinatorial",
    "cumulative_lattice_simplex_count",
    "delta_theta_prime",
    "delta_e",
    "div_mu",
    "eddy_viscosity",
    "e_field_natural_to_si",
    "emergent_maxwell_inhomogeneous_h",
    "emergent_maxwell_inhomogeneous_o",
    "emergent_maxwell_inhomogeneous_o_metric",
    "emergent_maxwell_inhomogeneous_o_si",
    "energy_natural_to_si_j",
    "force_natural_to_si",
    "friedmann_lhs",
    "friedmann_rhs",
    "g0",
    "g_eff",
    "g_rr",
    "g_si",
    "g_vac_vector",
    "gamma_hqiv",
    "h0",
    "h_of_phi",
    "hbar_si",
    "h0_ref",
    "horizon_quarter_period",
    "hqvm_friedmann_holds",
    "hqvm_friedmann_residual",
    "hqvm_g_tt",
    "hqvm_lapse",
    "hqvm_spatial_coeff",
    "in_h",
    "in_metric",
    "in_si",
    "lattice_simplex_count",
    "lattice_step_count",
    "length_natural_to_si",
    "maxwell3d_curl_b_minus_dedt",
    "maxwell3d_div_e",
    "modified_momentum_rhs",
    "new_modes",
    "now_condition",
    "octonion_imaginary_dim",
    "o_component_to_sector",
    "omega_k_at_horizon",
    "omega_k_partial",
    "x_over_theta_from_horizons",
    "phase_lift_coeff_real",
    "phase_conservation_numeric",
    "PlasmaFluidClosureHypothesis",
    "phi_of_real_shell",
    "phi_of_shell",
    "phi_of_temperature",
    "phi_temperature_coefficient",
    "qcd_shell",
    "reference_m",
    "rho_total",
    "structure_from_o_dim",
    "shell_index_for_temperature",
    "shell_mass_geometry_factor",
    "shell_shape",
    "shell_shape_real",
    "shell_temperature",
    "shell_temperature_factor",
    "signs_per_axis",
    "spatial_indices",
    "t_pl_natural",
    "build_action_snapshot",
    "build_conservation_check",
    "friedmann_from_action_equivalence_holds",
    "entropy_increment_per_shell",
    "entropy_production_proxy",
    "time_axis",
    "time_natural_to_si",
    "temperature_from_shell_index",
    "LegacyNowAnchorError",
    "NowGeometry",
    "active_slice",
    "m_now",
    "nowSetter",
    "now_geometry",
    "rescale_geometry",
    "now_set_from_electron_horizon",
    "equilibrium_rho_total_for_phi",
    "horizon_entropy_counting",
    "local_equilibrium_proxy",
    "three_minus_gamma",
    "time_angle",
    "two_pi",
    "unit_cube_half_diagonal",
    "wall_clock_age_homogeneous",
    "hqvm_friedmann_power_residual",
    "lapse_forces_time_angle_term",
    "o_maxwell_determines_hqvm_gr_homogeneous_equivalence",
    "s_hqvm_grav",
    "s_hqvm_grav_zero_holds",
    "second_law_arrow_holds",
    "temperature_at_shell",
    "SpinClass",
    "two_pi_phase",
    "exchange_phase_identical",
    "spin_statistics_exchange_sign_matches_two_pi",
    "hbar_MeV_s",
    "resonance_lifetime",
    "resonance_half_life",
    "ResonanceTimes",
    "build_resonance_times",
    "laplace_beltrami_eigenvalue_S2",
    "real_basis_dimension",
    "spherical_harmonic_Y",
    "spherical_harmonic_Y_real",
    "spherical_harmonic_real_basis_matrix",
    "DecayMode",
    "DecayStep",
    "IsotopeLadderConfig",
    "IsotopeState",
    "beta_half_life_s",
    "cross_section_geometric_barns",
    "cross_section_geometric_isotope_barns",
    "enumerate_decay_steps",
    "exoergic_decay_steps",
    "f_inertia",
    "gamma_half_life_proxy_s",
    "nuclear_binding_energy_mev",
    "nucleus_mass_mev",
    "rotational_excitation_mev",
    "SPECTRA_DEUTERON_BINDING_MEV",
    "Nucleus",
    "casimir_energy_surface",
    "deuteron_binding_scale",
    "ladder_path_from_ZN",
    "make_nucleus",
    "spherical_harmonic_cumulative_count",
    "valley_count_from_A",
    "alpha_gut",
    "one_over_alpha_eff",
    "alpha_eff_from_phi",
    "alpha_eff_at_shell",
    "coulomb_strength_shell",
    "expected_ground_energy_at_shell",
    "Operator",
    "Wavefunction",
    "lapse_factor",
    "lapse_corrected_hamiltonian",
    "satisfies_time_dependent_schrodinger_residual",
    "satisfies_lapse_corrected_schrodinger_residual",
    "coulomb_potential",
    "expected_ground_energy_shell",
    "shell_coulomb_strength",
    "SMConstantsAtNow",
    "sm_constants_at_now",
    "one_over_alpha_EM_at_MZ",
    "alpha_EM_at_MZ",
    "sin2thetaW_at_MZ",
    "alpha_s_at_MZ",
    "M_Pl_natural",
    "M_Z_natural",
    "m_electron_natural",
    "m_proton_MeV_central",
    "m_neutron_MeV_central",
    "SMLabel",
    "sm_generation_index",
    "sm_generation_offset",
    "sm_sector_multiplicity",
    "sm_hypercharge_weight",
    "sm_hypercharge_y2_table",
    "sm_hypercharge_eigenvalue_fin8",
    "SM_SU2_Generators",
    "sm_evolve_su2_on_8s",
    "sm_evolve_u1_hypercharge_8s",
    "sm_su2_l_generators_from_octonion",
    "sm_mass_from_geometry",
    "sm_mass_shell_real",
    "electron_geometry_factor",
    "natural_mass_to_eV",
    "sm_masses_from_geometry_at_default_now",
    "sm_masses_from_geometry_eV_at_default_now",
    "DERIVED_KEYS",
    "derived_gauge_outputs",
    "verify_pure_derived_keys_only",
    "DERIVED_NUCLEON_KEYS",
    "derived_nucleon_outputs",
    "format_nucleon_report",
    "verify_no_missing_keys",
    "So8Generators",
    "dump_so8_generators_json",
    "load_so8_generators",
    "load_so8_generators_auto",
    "load_so8_generators_from_json",
    "load_so8_generators_from_packaged_json",
    "lie_bracket",
    "so8_tensor_sha256_hex",
    "upper_triangle_coord",
    "So8Carrier",
    "hamiltonian_from_so8_coeffs",
    "HQIVState",
    "Circuit",
    "ComplexArray",
    "Gates",
    "NoiseModel",
    "QuantumState",
    "RunResult",
    "ValueWithError",
    "run_circuit",
    "DEFAULT_QUANTUM_SPECS",
    "LeanSymbolSpec",
    "quantum_lean_backing_ok",
    "validate_quantum_lean_backing",
    "GroverResult",
    "OraclePredicate",
    "PeriodFindingResult",
    "estimate_period_from_peaks",
    "hidden_tag_of",
    "optimal_grover_iterations",
    "oshoracle_grover_search",
    "oshoracle_period_find",
    "oshoracle_period_find_quantum",
    "period_probability_distribution",
    "period_support",
    "INSXxzResult",
    "INSXxzDenseVsTrotter",
    "apply_two_qubit_unitary_state",
    "benchmark_ins_xxz_dense_vs_trotter",
    "center_site_index",
    "rgf_to_spectral_mirror_avg",
    "simulate_xxz_rgf_center_kick",
    "simulate_xxz_rgf_center_kick_trotter",
    "spectrum_metrics_mse_wasserstein",
    "xxz_hamiltonian_open_chain",
    "xxz_nnn_hamiltonian_open_chain",
    "ProteinOshBenchCase",
    "protein_osh_benchmark_format_row",
    "protein_osh_benchmark_paper_cases",
    "protein_osh_benchmark_run_case",
    "protein_osh_benchmark_run_paper_table",
    # TUFT/Hopf kappa6 and C2 (second-order) for paper "D" (deuteron/mass) corrections ~0.12% level, matching current Lean
    "tuft_hopf_kappa6",
    "tuft_hopf_kappa6_second_order_correction",
    # Cosmic birefringence / self-clock at now (CMB polarization rotation, wall-clock age)
    "cosmic_birefringence_deg_at_now",
    "cosmic_birefringence_rad_at_now",
    "self_clock_cumulative_rapidity_cosmic_now",
    # First-principles baryon asymmetry / eta10 (dynamic shell integrator; paper script match, not the observed 6.1)
    "eta10_from_dynamic_first_principles",
    "derived_omega_b_at_lockin",
]

try:
    from pyhqiv._version import version as __version__
except ImportError:
    __version__ = "0.0.0+unknown"

# Re-export for top-level access (captures Lean for calculator / Arena)
from pyhqiv.lepton_resonance_ladder import (
    derived_omega_b_at_lockin,
    eta10_from_dynamic_first_principles,
    tuft_hopf_kappa6,
    tuft_hopf_kappa6_second_order_correction,
)

# Surface self-clock (wall-clock age, cosmic birefringence / polarization rotation at now)
from pyhqiv.surface_wave_self_clock import (
    cosmic_birefringence_deg_at_now,
    cosmic_birefringence_rad_at_now,
    self_clock_cumulative_rapidity_cosmic_now,
)

# Bonded-horizon chemistry (Lean: BondedHorizonCasimir, Ionic/MetallicContactSlot)
from pyhqiv.bonded_horizon_casimir import (
    bond_horizon_surplus_dimless,
    covalent_dimer_two_electron_surplus_dimless,
    ionic_bond_surplus_dimless,
    metallic_peel_surplus_dimless,
)
from pyhqiv.chemistry import (
    is_metallic_element,
    metallic_lattice_binding_dimless_per_contact,
    metallic_nearest_neighbor_separation_dimless,
    valence_electron_count,
)
from pyhqiv.nuclear_torus_perturbation import perturbed_casimir_energy

# Earth outside-closure K (Lean: NuclearOutsideTemperatureDynamics / ProtonMassDecomposition)
from pyhqiv.outside_closure import (
    LabOutsideEnvironment,
    OutsideClosureK,
    apply_outside_closure_k_to_outside_binding,
    default_earth_lab_environment,
    earth_outside_closure_k,
    outside_closure_k_at,
    xi_lockin,
)
from pyhqiv.curvature_binding import (
    EarthCorrectedOutsideBinding,
    earth_corrected_cluster_outside,
    try_build_curvature_row_earth,
)
