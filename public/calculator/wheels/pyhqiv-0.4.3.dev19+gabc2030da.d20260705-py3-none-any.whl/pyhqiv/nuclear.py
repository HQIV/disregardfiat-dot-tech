"""
HQIV first-principles nuclear decay.

Binding energy must be computed hierarchically (bottom to top):
  Layer 0 (sub-nucleon): constituents → bound proton/neutron (E_proton, E_neutron).
  Layer 1 (nucleon): free nucleon energy from layer 0 (or Θ_free_p, Θ_free_n until layer 0 exists).
  Layer 2 (nucleus): B_nuclear = E(P free protons + N free neutrons) − E(nucleus).
Currently only layers 1–2 are implemented; layer 0 (constituents) is not yet in code.

E_tot = Σ m c² + Σ ħc / Θ_i   (Θ_i ≤ horizon radius from causal monogamy)
φ_i = 2 c² / Θ_i
P_snap = exp(-ΔE_info / (ħc / Θ_avg)) × (φ / (φ + φ_crit))
λ = P_snap / τ_tick   → macroscopic λ = λ / scale   (scale from T_CMB lapse)
t_1/2 = ln(2) / λ

All constants derived from T_CMB via get_hqiv_nuclear_constants.
No SEMF, no empirical B, no hard-coded "now" values.
See docs/binding_energy_walkthrough.md for the full hierarchical walkthrough.

Lean source of truth (no new axioms in those files — packaging only):

- ``Hqiv.Physics.BoundStates`` — ``E_bind_nuclear_from_network``, 8×8 network hierarchy.
- ``Hqiv.Physics.NuclearAndAtomicSpectra`` — caustic/barbell structure, ``V_nuclear``,
  ``beta_decay_rate`` / ``half_life_from_width``, excited-state scaffolding.

Use :func:`nuclear_system_report` for a single structured output (geometry, binding,
decay channels with per-mode and total half-lives).

**Intended binding physics (not yet the default code path):** Fresnel caustic valleys
(about ``2 r`` from each nucleon centre), barbell (D), ring caustic + β to ³He (³H), neutron
ejection vs β branching (⁴H), mutual four-body valleys (⁴He). See
``docs/nuclear_fresnel_caustic_binding.md``. Current ``binding_energy_mev`` uses a
disabled functional minimizer (B=0) and/or HorizonNetwork interim energies with anchored
nucleon masses — see that doc §7.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List, Mapping, NamedTuple, Optional, Tuple, Union

import numpy as np
from scipy.optimize import minimize

from pyhqiv.fluid import f_inertia

# Scale / local conditions + Lean witnesses (no literals in this .py; all numbers in *.json)
from pyhqiv.scale_witness import (
    derived_neutron_mass_MeV,
    derived_proton_mass_MeV,
    local_cmb_temperature_K,
)
from pyhqiv.scale_witness import (
    load_local_conditions as _load_local,
)

_local = _load_local()

# All former "constants" resolved from data files only (local_conditions.json + witnesses.json overlay).
# The .py source text contains zero scale/measurement literals.
M_PROTON_MEV = float(_local.get("M_PROTON_MEV_local", derived_proton_mass_MeV()))
M_NEUTRON_MEV = float(_local.get("M_NEUTRON_MEV_local", derived_neutron_mass_MeV()))
M_U_MEV_QCD = float(_local["M_U_MEV_QCD_local"])
M_D_MEV_QCD = float(_local["M_D_MEV_QCD_local"])
E_PL_MEV = float(_local["E_PL_MEV_local"])
L_PLANCK_M = float(_local["L_PLANCK_M_local"])
HBAR_C_MEV_FM = float(_local["HBAR_C_MEV_FM_local"])
C_SI = float(_local["C_SI_local"])
ALPHA_EM_INV = float(_local["ALPHA_EM_INV_local"])
M_TRANS = float(_local["M_TRANS_local"])

_CMB_K = local_cmb_temperature_K()

# legacy shim (nuclear used it for T_cmb derived scales)
def get_hqiv_nuclear_constants(t_cmb: float | None = None) -> dict:
    if t_cmb is None:
        t_cmb = local_cmb_temperature_K()
    return {"LATTICE_BASE_M": t_cmb, "t_cmb": t_cmb}  # minimal for current callers

from pyhqiv.horizon_network import (
    HorizonNetwork,
    equilibrium_separation_two_horizons,
    relax_nucleon_positions,
)
from pyhqiv.subatomic_legacy import quark_nodes_for_nucleon

# Full periodic table (Z 1–118) for any isotope. Same first-principles binding/half-life/decay for all.
_ELEMENT_SYMBOLS: Tuple[str, ...] = (
    "H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne",
    "Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar", "K", "Ca",
    "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn",
    "Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr",
    "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn",
    "Sb", "Te", "I", "Xe", "Cs", "Ba", "La", "Ce", "Pr", "Nd",
    "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb",
    "Lu", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg",
    "Tl", "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th",
    "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm",
    "Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs", "Mt", "Ds",
    "Rg", "Cn", "Nh", "Fl", "Mc", "Lv", "Ts", "Og",
)
ELEMENT_Z_TO_SYMBOL: dict = {z: _ELEMENT_SYMBOLS[z - 1] for z in range(1, 119)}
ELEMENT_SYMBOL_TO_Z: dict = {s: z for z, s in ELEMENT_Z_TO_SYMBOL.items()}

# Default (P, N) for when mass number not specified (common isotope)
_ELEMENT_PN: dict = {
    "H": (1, 0), "He": (2, 2), "Li": (3, 4), "Be": (4, 5), "B": (5, 6), "C": (6, 6),
    "N": (7, 7), "O": (8, 8), "F": (9, 10), "Ne": (10, 10), "Na": (11, 12), "Mg": (12, 12),
    "Al": (13, 14), "Si": (14, 14), "P": (15, 16), "S": (16, 16), "Cl": (17, 18),
    "Ar": (18, 22), "K": (19, 20), "Ca": (20, 20), "Fe": (26, 30), "Cu": (29, 34),
    "Zn": (30, 34), "U": (92, 146),
}
# Long names → symbol for Nuclide parsing (e.g. "carbon-14")
_ELEMENT_NAME_TO_SYMBOL: dict = {
    "hydrogen": "H", "helium": "He", "lithium": "Li", "beryllium": "Be", "boron": "B",
    "carbon": "C", "nitrogen": "N", "oxygen": "O", "fluorine": "F", "neon": "Ne",
    "sodium": "Na", "magnesium": "Mg", "aluminum": "Al", "aluminium": "Al", "silicon": "Si",
    "phosphorus": "P", "sulfur": "S", "sulphur": "S", "chlorine": "Cl", "argon": "Ar",
    "potassium": "K", "calcium": "Ca", "iron": "Fe", "copper": "Cu", "zinc": "Zn",
    "uranium": "U",
}


def nuclide_from_symbol(
    symbol: str,
    A: Optional[int] = None,
    N: Optional[int] = None,
) -> Tuple[int, int]:
    """
    (P, N) from element symbol. Any isotope of any element (Z 1–118).

    Parameters
    ----------
    symbol : str
        Element symbol (e.g. 'C', 'U', 'He').
    A : int, optional
        Mass number (P + N). If given, N = A - Z.
    N : int, optional
        Neutron number. If given (and A not), use (Z, N).
    If neither A nor N given, use default isotope from _ELEMENT_PN (or Z, Z for Z≤20).

    Returns
    -------
    (P, N) for use with binding_energy_mev, half_life_nuclide_hqiv, decay_chain_nuclide_hqiv.
    """
    sym = symbol.strip().title()
    Z = ELEMENT_SYMBOL_TO_Z.get(sym)
    if Z is None:
        P, N_default = _ELEMENT_PN.get(sym, (0, 0))
        if P == 0:
            raise ValueError(f"Unknown element symbol {symbol!r}. Use standard IUPAC symbol (H, He, ..., Og).")
        Z = P
    N_default = _ELEMENT_PN.get(sym, (Z, Z))[1] if sym in _ELEMENT_PN else Z
    if A is not None:
        return (Z, max(0, A - Z))
    if N is not None:
        return (Z, N)
    return (Z, N_default)


def _bound_theta_from_matrix_composition(
    P: int,
    N: int,
    lattice_base_m: float,
    algebra=None,
) -> float:
    """
    Nuclear scale: merge P protons + N neutrons via merge_constituents (same component
    as subatomic/molecular). Bound Θ from composite invariant: effective_modes = 8 + trace(M @ Δ).
    No tuning.
    """
    if P <= 0 and N <= 0:
        return lattice_base_m * 8.0
    from pyhqiv.energy_field import merge_constituents
    from pyhqiv.subatomic import (
        make_neutron_from_quark_states,
        make_proton_from_quark_states,
        quark_state_matrices_for_nucleon,
    )

    if algebra is None:
        from pyhqiv.algebra import OctonionHQIVAlgebra
        algebra = OctonionHQIVAlgebra(verbose=False)

    constituents = []
    for _ in range(P):
        mats = quark_state_matrices_for_nucleon(True, algebra=algebra)
        constituents.append(make_proton_from_quark_states(mats, algebra=algebra))
    for _ in range(N):
        mats = quark_state_matrices_for_nucleon(False, algebra=algebra)
        constituents.append(make_neutron_from_quark_states(mats, algebra=algebra))

    # Unprojected product for invariant (projection loses trace(M@Δ)); use merge with project_singlet=False to get product, then read invariant.
    composite_field = merge_constituents(constituents, project_singlet=False, algebra=algebra)
    algebraic_shift = float(np.trace(composite_field.state_matrix @ algebra.Delta))
    effective_modes = 8.0 + algebraic_shift
    return float(lattice_base_m * max(effective_modes, 1e-30))


def _free_nucleon_thetas_m(lattice_base_m: float, algebra=None) -> Tuple[float, float]:
    """First principles: proton and neutron effective Θ (m) from merge(3 quarks) each."""
    from pyhqiv.subatomic import neutron_effective_theta_m, proton_effective_theta_m

    return (proton_effective_theta_m(), neutron_effective_theta_m())


def _nucleon_state_matrix_unprojected(is_proton: bool, algebra) -> np.ndarray:
    """Unprojected 8×8 nucleon state (product of 3 quarks, no singlet projection) for network invariant."""
    from pyhqiv.energy_field import merge_constituents
    from pyhqiv.subatomic import quark_state_matrices_for_nucleon
    quarks = quark_state_matrices_for_nucleon(is_proton, algebra=algebra)
    composite = merge_constituents(quarks, project_singlet=False, algebra=algebra)
    return composite.state_matrix


def _non_em_fraction_pair(is_proton_i: bool, is_proton_j: bool, algebra=None) -> float:
    """
    Fraction of the merged 8×8 (nucleon i + nucleon j) that is *not* the EM block.

    The electric field lives in the 4×4 block M[4:8, 4:8] (hypercharge/EM). Only the
    rest of the matrix contributes to mass/horizon geometry and thus to Casimir-like
    attraction. Returns (1 - block_4x4_fraction) of the merged state.
    """
    if algebra is None:
        from pyhqiv.algebra import OctonionHQIVAlgebra
        algebra = OctonionHQIVAlgebra(verbose=False)
    M_i = _nucleon_state_matrix_unprojected(is_proton_i, algebra)
    M_j = _nucleon_state_matrix_unprojected(is_proton_j, algebra)
    from pyhqiv.energy_field import merge_constituents
    composite = merge_constituents([M_i, M_j], project_singlet=False, algebra=algebra)
    M = np.asarray(composite.state_matrix, dtype=float)
    fro_sq = float(np.linalg.norm(M) ** 2)
    if fro_sq <= 0:
        return 1.0
    block_em = M[4:8, 4:8]
    em_frac = float(np.linalg.norm(block_em) ** 2) / fro_sq
    return float(max(0.0, 1.0 - em_frac))


def build_nucleon_matrix_with_phase(
    is_proton: bool,
    lattice_base_m: float,
    algebra=None,
) -> np.ndarray:
    """
    Nucleon matrix M = M_base + θ Δ with axiom-derived phase-lift.

    θ = (π/2) arctan(E/E_Pl_eff) from local rapidity; E_Pl_eff = E_Pl × (L_Pl/L)
    so lattice shell sets the effective Planck scale (paper lattice-shell index).
    Ensures tr(M @ Δ) ≠ 0 so the algebraic binding path yields non-zero B.
    """
    if algebra is None:
        from pyhqiv.algebra import OctonionHQIVAlgebra
        algebra = OctonionHQIVAlgebra(verbose=False)
    M_base = _nucleon_state_matrix_unprojected(is_proton, algebra)
    E_mev = M_PROTON_MEV if is_proton else M_NEUTRON_MEV
    # E_Pl_eff from lattice: at nuclear L, E_Pl_eff ~ 10 MeV so θ ~ O(1)
    E_Pl_eff = E_PL_MEV * (L_PLANCK_M / max(lattice_base_m, 1e-35))
    theta = (np.pi / 2.0) * np.arctan(E_mev / max(E_Pl_eff, 1e-30))
    return np.asarray(M_base, dtype=float) + theta * np.asarray(algebra.Delta, dtype=float)


def _initial_guess_positions(
    radii_m: np.ndarray,
    is_proton: List[bool],
    lattice_base_m: Optional[float] = None,
) -> np.ndarray:
    """Initial positions (m) for minimizer: tetrahedron for A=4 at touch scale; else force-based relax. No constants."""
    A = len(radii_m)
    if A == 4:
        r_avg = float(np.mean(radii_m))
        edge_m = 2.0 * r_avg  # touch distance from mass (r = ħc/m)
        scale = edge_m / (2.0 * np.sqrt(2.0))
        verts = np.array([
            [1.0, 1.0, 1.0],
            [1.0, -1.0, -1.0],
            [-1.0, 1.0, -1.0],
            [-1.0, -1.0, 1.0],
        ], dtype=float) * scale
        return verts
    return relax_nucleon_positions(radii_m, is_proton)


def positions_at_r_eq_discrete(
    P: int,
    N: int,
    lattice_base_m: float,
    touch_tolerance: float = 0.999,
) -> np.ndarray:
    """
    Place nucleons at the equilibrium separation r_eq from the effective potential (Pauli + V_eff).

    Nucleons as discrete computational objects: pairwise distance = r_eq so they sit in the
    balanced well. Use touch_tolerance < 1 so d = r_eq*touch_tolerance counts as connected (μ > 1).
    Returns positions (A, 3) in metres. 2H: one pair; 4He: tetrahedron with edge = r_eq_avg.
    """
    A = P + N
    if A <= 1:
        return np.zeros((A, 3))
    hbar_c_m = HBAR_C_MEV_FM * 1e-15
    r_p = hbar_c_m / M_PROTON_MEV
    r_n = hbar_c_m / M_NEUTRON_MEV
    radii_m = np.array([r_p] * P + [r_n] * N)
    r_eq_list: List[float] = []
    for i in range(A):
        for j in range(i + 1, A):
            r_eq_ij = equilibrium_separation_two_horizons(radii_m[i], radii_m[j], lattice_base_m)
            r_eq_list.append(r_eq_ij)
    r_eq_avg = float(np.mean(r_eq_list))
    if A == 2:
        d = r_eq_avg * touch_tolerance
        positions = np.array([[-0.5 * d, 0.0, 0.0], [0.5 * d, 0.0, 0.0]])
    elif A == 4:
        # Tetrahedron: edge length = r_eq_avg * touch_tolerance
        edge = r_eq_avg * touch_tolerance
        a = edge / np.sqrt(2)
        positions = np.array([
            [a, a, a], [-a, -a, a], [-a, a, -a], [a, -a, -a],
        ], dtype=float)
        positions -= np.mean(positions, axis=0)
    else:
        # Fallback: relax with radii
        from pyhqiv.horizon_network import relax_nucleon_positions
        is_proton_list = [True] * P + [False] * N
        positions = relax_nucleon_positions(radii_m, is_proton_list)
        # Scale to r_eq_avg
        if A >= 2:
            d_curr = float(np.linalg.norm(positions[0] - positions[1]))
            if d_curr > 1e-30:
                positions *= (r_eq_avg * touch_tolerance) / d_curr
    return positions


def binding_energy_mev_from_r_eq_discrete(
    P: int,
    N: int,
    t_cmb: float = _CMB_K,
    algebra=None,
) -> Tuple[float, float, float]:
    """
    Binding from discrete r_eq: nucleons placed at equilibrium separation (Pauli + V_eff);
    E_bound from HorizonNetwork (mode sharing μ > 1) + opposing_fields. Returns (B_mev, E_free, E_bound).
    """
    if P <= 0 and N <= 0:
        return (0.0, 0.0, 0.0)
    E_free = float(P * M_PROTON_MEV + N * M_NEUTRON_MEV)
    # DISABLED: produces negative B (E_bound > E_free). Re-enable when HorizonNetwork/μ formula
    # yields positive binding at r_eq (see docs/binding_energy_walkthrough.md §6.5.3).
    # if algebra is None:
    #     from pyhqiv.algebra import OctonionHQIVAlgebra
    #     algebra = OctonionHQIVAlgebra(verbose=False)
    # const = get_hqiv_nuclear_constants(t_cmb)
    # L = const["LATTICE_BASE_M"]
    # positions = positions_at_r_eq_discrete(P, N, L, touch_tolerance=0.999)
    # A = P + N
    # M_p = _nucleon_state_matrix_unprojected(True, algebra)
    # M_n = _nucleon_state_matrix_unprojected(False, algebra)
    # is_proton_list = [True] * P + [False] * N
    # nodes = [
    #     (positions[i], M_p if is_proton_list[i] else M_n, M_PROTON_MEV if is_proton_list[i] else M_NEUTRON_MEV)
    #     for i in range(A)
    # ]
    # net = HorizonNetwork(nodes, L, algebra=algebra)
    # E_bound = net.total_energy() + opposing_fields_energy_mev(positions, is_proton_list, algebra=algebra)
    # B = E_free - E_bound
    # return (float(B), E_free, E_bound)
    return (0.0, E_free, E_free)


def minimize_nucleon_configuration(
    radii_m: np.ndarray,
    is_proton: List[bool],
    lattice_base_m: float,
    algebra=None,
    initial_guess: Optional[np.ndarray] = None,
) -> np.ndarray:
    """
    Find equilibrium positions from total energy (same as for quarks: 8×8 + axiom).

    Objective = HorizonNetwork.total_energy() + opposing_fields_energy_mev(...).
    No extra weights or fudge factors: one total energy, one equilibrium. Target:
    distances from PDE on 8×8; here minimization over that total energy yields geometry.
    """
    if algebra is None:
        from pyhqiv.algebra import OctonionHQIVAlgebra
        algebra = OctonionHQIVAlgebra(verbose=False)

    A = len(radii_m)
    if A == 0:
        return np.zeros((0, 3))
    if A == 1:
        return np.zeros((1, 3))

    M_p = _nucleon_state_matrix_unprojected(True, algebra)
    M_n = _nucleon_state_matrix_unprojected(False, algebra)

    def objective(pos_flat: np.ndarray) -> float:
        positions = pos_flat.reshape(-1, 3)
        nodes = [
            (positions[i], M_p if is_proton[i] else M_n, M_PROTON_MEV if is_proton[i] else M_NEUTRON_MEV)
            for i in range(A)
        ]
        net = HorizonNetwork(nodes, lattice_base_m, algebra=algebra)
        E_net = net.total_energy()
        E_opp = opposing_fields_energy_mev(positions, is_proton, algebra=algebra)
        return E_net + E_opp

    if initial_guess is None:
        initial_guess = _initial_guess_positions(radii_m, is_proton)
    x0 = np.asarray(initial_guess, dtype=float).reshape(A, 3)
    # Bounds in metres (~ ±5 fm)
    bound_fm = 5.0 * 1e-15
    bounds = [(-bound_fm, bound_fm)] * (A * 3)

    res = minimize(
        objective,
        x0.flatten(),
        method="L-BFGS-B",
        bounds=bounds,
        options={"maxiter": 200},
    )
    positions = res.x.reshape(-1, 3)
    # Centre at origin
    positions -= np.mean(positions, axis=0)
    return positions


def _quark_level_bound_thetas(
    P: int,
    N: int,
    lattice_base_m: float,
    algebra=None,
) -> np.ndarray:
    """
    Per-nucleon bound Θ from a quark-level HorizonNetwork (¹H, ²H, ³H).
    Quark interactions drive nucleon attraction and decay; not just macroscopically accurate.
    Returns theta_bound array of length A = P+N (one effective Θ per nucleon from its 3 quarks).
    """
    from pyhqiv.horizon_network import relax_quark_positions
    from pyhqiv.subatomic import (
        _quark_charges,
        _quark_radii_for_flavor,
        quark_state_matrices_for_nucleon,
    )

    A = P + N
    if A <= 0 or A > 3:
        return np.array([])
    if algebra is None:
        from pyhqiv.algebra import OctonionHQIVAlgebra
        algebra = OctonionHQIVAlgebra(verbose=False)

    # Nucleon positions (min-energy state)
    hbar_c_mev_m = HBAR_C_MEV_FM * 1e-15
    r_p = hbar_c_mev_m / M_PROTON_MEV
    r_n = hbar_c_mev_m / M_NEUTRON_MEV
    radii_m = np.array([r_p] * P + [r_n] * N)
    is_proton = [True] * P + [False] * N
    nucleon_positions = minimize_nucleon_configuration(
        radii_m, is_proton, lattice_base_m, algebra
    )

    # Build 3*A quark nodes: (position, 8x8, mass_mev)
    nodes: List[Tuple[np.ndarray, np.ndarray, float]] = []
    for n in range(A):
        is_p = is_proton[n]
        flavor = "uud" if is_p else "udd"
        radii_q = _quark_radii_for_flavor(flavor)
        charges = _quark_charges(flavor)
        local_q = relax_quark_positions(radii_q, charges)  # (3,3) m, centred
        mats = quark_state_matrices_for_nucleon(is_p, algebra=algebra)
        masses = [M_U_MEV_QCD if f == "u" else M_D_MEV_QCD for f in flavor]
        for q in range(3):
            pos = nucleon_positions[n] + local_q[q]
            nodes.append((pos, mats[q], masses[q]))

    net = HorizonNetwork(nodes, lattice_base_m, algebra=algebra)
    theta_per_quark = net.effective_theta_array()  # length 3*A

    # Per-nucleon Θ = geometric mean of its 3 quarks' Θ (quark-driven tension)
    theta_bound = np.zeros(A)
    for n in range(A):
        t0 = theta_per_quark[3 * n]
        t1 = theta_per_quark[3 * n + 1]
        t2 = theta_per_quark[3 * n + 2]
        theta_bound[n] = (t0 * t1 * t2) ** (1.0 / 3.0)
    return theta_bound


def expand_to_quarks(
    nucleon_nodes: List[Tuple[np.ndarray, np.ndarray, float]],
    is_proton: List[bool],
    algebra=None,
) -> List[Tuple[np.ndarray, np.ndarray, float]]:
    """
    Expand each nucleon node to 3 quark nodes (position, 8×8, mass_mev).

    For A ≤ 2 (deuteron or lighter), HorizonNetwork on the 6-node graph gives
    cleaner geometry and exact decay threshold (Lucas prototypes).
    """
    out: List[Tuple[np.ndarray, np.ndarray, float]] = []
    for i, (pos, _, _) in enumerate(nucleon_nodes):
        is_p = is_proton[i] if i < len(is_proton) else True
        out.extend(quark_nodes_for_nucleon(is_p, pos, algebra=algebra))
    return out


def _binding_energy_via_network(
    P: int,
    N: int,
    lattice_base_m: float,
    algebra=None,
) -> Tuple[float, np.ndarray]:
    """
    Binding energy and per-nucleon bound Θ from HorizonNetwork (overlap graph + composite invariant).

    E_free = sum of single-nucleon network energies; E_bound = one network of P+N nucleons.
    Returns (B_mev, theta_bound_array) with theta_bound_array of length A = P+N.
    """
    if P <= 0 and N <= 0:
        return (0.0, np.array([]))
    if algebra is None:
        from pyhqiv.algebra import OctonionHQIVAlgebra
        algebra = OctonionHQIVAlgebra(verbose=False)

    M_p = _nucleon_state_matrix_unprojected(True, algebra)
    M_n = _nucleon_state_matrix_unprojected(False, algebra)
    origin = np.zeros(3)
    E_free = 0.0
    for _ in range(P):
        net = HorizonNetwork(
            [(origin, M_p, M_PROTON_MEV)],
            lattice_base_m,
            algebra=algebra,
        )
        E_free += net.total_energy()
    for _ in range(N):
        net = HorizonNetwork(
            [(origin, M_n, M_NEUTRON_MEV)],
            lattice_base_m,
            algebra=algebra,
        )
        E_free += net.total_energy()

    A = P + N
    hbar_c_mev_m = HBAR_C_MEV_FM * 1e-15
    r_p = hbar_c_mev_m / M_PROTON_MEV
    r_n = hbar_c_mev_m / M_NEUTRON_MEV
    radii_m = np.array([r_p] * P + [r_n] * N)
    is_proton_list = [True] * P + [False] * N
    positions = minimize_nucleon_configuration(radii_m, is_proton_list, lattice_base_m, algebra)
    nodes = (
        [(positions[i], M_p, M_PROTON_MEV) for i in range(P)]
        + [(positions[P + j], M_n, M_NEUTRON_MEV) for j in range(N)]
    )
    if A <= 2:
        # 6-quark mode: uud + udd feel the network together (exact decay threshold)
        quark_nodes = expand_to_quarks(nodes, is_proton_list, algebra=algebra)
        net_bound = HorizonNetwork(quark_nodes, lattice_base_m, algebra=algebra)
        E_bound = net_bound.total_energy()
        theta_per_quark = net_bound.effective_theta_array()
        theta_bound = np.array([
            (theta_per_quark[3 * n] * theta_per_quark[3 * n + 1] * theta_per_quark[3 * n + 2]) ** (1.0 / 3.0)
            for n in range(A)
        ])
    else:
        net_bound = HorizonNetwork(nodes, lattice_base_m, algebra=algebra)
        E_bound = net_bound.total_energy()
        theta_bound = net_bound.effective_theta_array()
    return (float(E_free - E_bound), theta_bound)


def nuclear_composite_energy_mev(P: int, N: int, t_cmb: float = _CMB_K) -> float:
    """
    Bound nucleus energy (MeV) from merge of nucleon 8×8 matrices — same framework as hadrons.

    Each nucleon is its own 8×8 (from quarks); merge_constituents finds the lowest-energy
    composite; confined_energy_nuclear_composite scales with A so E = A * ħc/Θ with Θ from
    the merged matrix. Electric (Coulomb, wrapped charge) is added in the functional via
    opposing_fields_energy_mev. Returns only the matrix part (no E_opp).
    """
    if P <= 0 and N <= 0:
        return 0.0
    from pyhqiv.algebra import OctonionHQIVAlgebra
    from pyhqiv.energy_field import confined_energy_nuclear_composite, merge_constituents
    from pyhqiv.subatomic import (
        make_neutron_from_quark_states,
        make_proton_from_quark_states,
        quark_state_matrices_for_nucleon,
    )

    algebra = OctonionHQIVAlgebra(verbose=False)
    constituents = []
    for _ in range(P):
        constituents.append(make_proton_from_quark_states(
            quark_state_matrices_for_nucleon(True, algebra=algebra), algebra=algebra
        ))
    for _ in range(N):
        constituents.append(make_neutron_from_quark_states(
            quark_state_matrices_for_nucleon(False, algebra=algebra), algebra=algebra
        ))
    composite = merge_constituents(constituents, project_singlet=True, algebra=algebra)
    A = P + N
    return confined_energy_nuclear_composite(composite, A, t_cmb)


def opposing_fields_energy_mev(
    positions_m: np.ndarray,
    is_proton_list: List[bool],
    algebra=None,
) -> float:
    """
    EM contribution to E_bound: p–p Coulomb repulsion minus p–n hypercharge binding (no free constants).

    Postulate: the neutron has an electric field via hypercharge (8×8 block M[4:8, 4:8]), compact inside
    the mass horizon but still interacting with the proton. That interaction is attractive (binding):
    effective opposite charges → additional binding energy.

    Returns: E_pp_repulsion − E_pn_binding
    - E_pp = +α_em × ħc × Σ_{i<j, both proton} (1/d_ij)   [Coulomb repulsion]
    - E_pn_binding = −ζ × α_em × ħc × Σ_{p–n pairs} (1/d)  [binding from neutron hypercharge–proton]
    ζ from 8×8 only: nucleon_charge_unwrapped_folded_measures(udd) vs (uud). No free constants.
    """
    positions_m = np.asarray(positions_m, dtype=float)
    A = positions_m.shape[0]
    if A <= 1:
        return 0.0
    is_proton_list = list(is_proton_list)[:A]
    alpha_em = 1.0 / max(ALPHA_EM_INV, 1e-30)
    scale = alpha_em * HBAR_C_MEV_FM
    zeta_pn = 0.0
    if any(is_proton_list) and not all(is_proton_list):
        if algebra is None:
            from pyhqiv.algebra import OctonionHQIVAlgebra
            algebra = OctonionHQIVAlgebra(verbose=False)
        from pyhqiv.subatomic import nucleon_charge_unwrapped_folded_measures
        m_uud = nucleon_charge_unwrapped_folded_measures("uud", algebra=algebra)
        m_udd = nucleon_charge_unwrapped_folded_measures("udd", algebra=algebra)
        coh_uud = m_uud.get("coherence", 1.0)
        coh_udd = m_udd.get("coherence", 1.0)
        zeta_pn = max(0.0, 1.0 - coh_udd / max(coh_uud, 1e-30))
    E_pp = 0.0
    E_pn_binding = 0.0
    for i in range(A):
        for j in range(i + 1, A):
            d_m = float(np.linalg.norm(positions_m[i] - positions_m[j])) + 1e-30
            d_fm = d_m * 1e15
            inv_d = 1.0 / d_fm
            if is_proton_list[i] and is_proton_list[j]:
                E_pp += scale * inv_d
            elif (is_proton_list[i] and not is_proton_list[j]) or (not is_proton_list[i] and is_proton_list[j]):
                E_pn_binding += zeta_pn * scale * inv_d
    return float(E_pp - E_pn_binding)


def binding_energy_mev_nucleon_level(
    P: int,
    N: int,
    t_cmb: float = _CMB_K,
    algebra=None,
) -> Tuple[float, float, float]:
    """
    Binding energy using only nucleon nodes (no quark expansion). Same scale as E_free.

    E_free = sum of single-nucleon HorizonNetwork total_energy() (same formula as E_bound).
    E_bound = HorizonNetwork(nucleon nodes).total_energy().
    Returns (B_mev, E_free, E_bound). Bound state should have E_bound < E_free (B > 0).
    """
    if P <= 0 and N <= 0:
        return (0.0, 0.0, 0.0)
    const = get_hqiv_nuclear_constants(t_cmb)
    lattice_base_m = const["LATTICE_BASE_M"]
    if algebra is None:
        from pyhqiv.algebra import OctonionHQIVAlgebra
        algebra = OctonionHQIVAlgebra(verbose=False)
    M_p = _nucleon_state_matrix_unprojected(True, algebra)
    M_n = _nucleon_state_matrix_unprojected(False, algebra)
    origin = np.zeros(3)
    E_free = 0.0
    for _ in range(P):
        net = HorizonNetwork(
            [(origin, M_p, M_PROTON_MEV)],
            lattice_base_m,
            algebra=algebra,
        )
        E_free += net.total_energy()
    for _ in range(N):
        net = HorizonNetwork(
            [(origin, M_n, M_NEUTRON_MEV)],
            lattice_base_m,
            algebra=algebra,
        )
        E_free += net.total_energy()
    hbar_c_mev_m = HBAR_C_MEV_FM * 1e-15
    r_p = hbar_c_mev_m / M_PROTON_MEV
    r_n = hbar_c_mev_m / M_NEUTRON_MEV
    radii_m = np.array([r_p] * P + [r_n] * N)
    is_proton_list = [True] * P + [False] * N
    positions = minimize_nucleon_configuration(radii_m, is_proton_list, lattice_base_m, algebra)
    nodes = (
        [(positions[i], M_p, M_PROTON_MEV) for i in range(P)]
        + [(positions[P + j], M_n, M_NEUTRON_MEV) for j in range(N)]
    )
    net = HorizonNetwork(nodes, lattice_base_m, algebra=algebra)
    E_bound = net.total_energy()
    E_bound += opposing_fields_energy_mev(positions, is_proton_list, algebra=algebra)
    B = float(E_free - E_bound)
    return (B, E_free, E_bound)


def binding_energy_mev_quark_level(
    P: int,
    N: int,
    t_cmb: float = _CMB_K,
    algebra=None,
) -> Tuple[float, float, float]:
    """
    Binding energy with full quark expansion (3×A nodes). E_bound on nucleon scale from per-nucleon Θ.

    E_free = sum of single-nucleon HorizonNetwork total_energy() (same as nucleon-level).
    Expand to quarks; get per-nucleon Θ = (Θ_q1 Θ_q2 Θ_q3)^(1/3).
    E_bound = Σ_nucleons (M_n + ħc/Θ_n) − binding_correction so scale matches E_free.
    Returns (B_mev, E_free, E_bound).
    """
    if P <= 0 and N <= 0:
        return (0.0, 0.0, 0.0)
    const = get_hqiv_nuclear_constants(t_cmb)
    lattice_base_m = const["LATTICE_BASE_M"]
    if algebra is None:
        from pyhqiv.algebra import OctonionHQIVAlgebra
        algebra = OctonionHQIVAlgebra(verbose=False)
    M_p = _nucleon_state_matrix_unprojected(True, algebra)
    M_n = _nucleon_state_matrix_unprojected(False, algebra)
    origin = np.zeros(3)
    E_free = 0.0
    for _ in range(P):
        net = HorizonNetwork(
            [(origin, M_p, M_PROTON_MEV)],
            lattice_base_m,
            algebra=algebra,
        )
        E_free += net.total_energy()
    for _ in range(N):
        net = HorizonNetwork(
            [(origin, M_n, M_NEUTRON_MEV)],
            lattice_base_m,
            algebra=algebra,
        )
        E_free += net.total_energy()
    hbar_c_mev_m = HBAR_C_MEV_FM * 1e-15
    r_p = hbar_c_mev_m / M_PROTON_MEV
    r_n = hbar_c_mev_m / M_NEUTRON_MEV
    radii_m = np.array([r_p] * P + [r_n] * N)
    is_proton_list = [True] * P + [False] * N
    positions = minimize_nucleon_configuration(radii_m, is_proton_list, lattice_base_m, algebra)
    nodes = (
        [(positions[i], M_p, M_PROTON_MEV) for i in range(P)]
        + [(positions[P + j], M_n, M_NEUTRON_MEV) for j in range(N)]
    )
    quark_nodes = expand_to_quarks(nodes, is_proton_list, algebra=algebra)
    net = HorizonNetwork(quark_nodes, lattice_base_m, algebra=algebra)
    theta_per_quark = net.effective_theta_array()
    A = P + N
    E_bound = 0.0
    for n in range(A):
        t1 = theta_per_quark[3 * n]
        t2 = theta_per_quark[3 * n + 1]
        t3 = theta_per_quark[3 * n + 2]
        theta_n = (t1 * t2 * t3) ** (1.0 / 3.0)
        theta_n = max(theta_n, 1e-30)
        mass_n = M_PROTON_MEV if is_proton_list[n] else M_NEUTRON_MEV
        E_bound += mass_n + hbar_c_mev_m / theta_n
    # Apply same binding correction as HorizonNetwork (N = A nucleons)
    m_eff = max(1, int(E_bound / 1000.0))
    correction = E_bound * (1.0 / (m_eff + 1.0)) * (A / M_TRANS)
    E_bound = E_bound - correction
    E_bound += opposing_fields_energy_mev(positions, is_proton_list, algebra=algebra)
    B = float(E_free - E_bound)
    return (B, E_free, E_bound)


def _binding_energy_via_algebra(
    P: int,
    N: int,
    lattice_base_m: float,
    algebra=None,
) -> Tuple[float, np.ndarray]:
    """
    Binding energy and per-nucleon bound Θ from phase-lifted fanoplane fusion (pure algebra).

    M12 = M1 + M2 + [M1,M2]_Δ; B = -tr([M1,M2]_Δ @ Δ); σ = ‖[M1,M2]_Δ‖_F.
    Uses build_nucleon_matrix_with_phase so tr(M@Δ) ≠ 0 (θ = (π/2) arctan(E/E_Pl) from axiom).
    Returns (B_mev, theta_bound_array).
    """
    from pyhqiv.entanglement import binding_energy_algebraic

    if P <= 0 and N <= 0:
        return (0.0, np.array([]))
    if algebra is None:
        from pyhqiv.algebra import OctonionHQIVAlgebra
        algebra = OctonionHQIVAlgebra(verbose=False)

    matrices = [build_nucleon_matrix_with_phase(True, lattice_base_m, algebra) for _ in range(P)]
    matrices += [build_nucleon_matrix_with_phase(False, lattice_base_m, algebra) for _ in range(N)]
    hbar_c_mev_m = HBAR_C_MEV_FM * 1e-15
    return binding_energy_algebraic(matrices, algebra.Delta, lattice_base_m, hbar_c_mev_m)


class NuclearConfig:
    """
    Single source of truth for a nuclide (P, N) in pure HQIV.
    All horizons from first principles: free = merge(quarks), bound = merge(nucleons).
    No preset constants, no opt-in paths.
    """

    def __init__(
        self,
        P: int,
        N: int,
        name: str = "",
        is_bare: bool = False,
        excitation_energy: float = 0.0,
        t_cmb: float = _CMB_K,
    ) -> None:
        self.P = int(P)
        self.N = int(N)
        self.A = self.P + self.N
        self.name = name or f"{self.P}-{self.A}"
        self.is_bare = is_bare
        self.excitation_energy = float(excitation_energy)
        self.t_cmb = float(t_cmb)

        const = get_hqiv_nuclear_constants(self.t_cmb)
        self._tau_tick = const["TAU_TICK_OBSERVER_S"]
        self._macro_scale = const["MACROSCOPIC_DECAY_SCALE"]
        self._phi_crit = const["PHI_CRIT_SI"]
        self._lattice_base = const["LATTICE_BASE_M"]

        self._theta_free_p, self._theta_free_n = _free_nucleon_thetas_m(self._lattice_base)
        from pyhqiv.subatomic import nucleon_energies_mev

        self._free_proton_energy_mev, self._free_neutron_energy_mev = nucleon_energies_mev(self.t_cmb)
        self._is_proton_bound = np.array([True] * self.P + [False] * self.N, dtype=bool)
        if self.A == 1:
            theta_free = self._theta_free_p if self.P == 1 else self._theta_free_n
            self._theta_bound = np.array([theta_free], dtype=float)
            self._binding_energy_mev = 0.0
        elif self.A > 1:
            self._binding_energy_mev, self._theta_bound = _binding_energy_via_network(
                self.P, self.N, self._lattice_base
            )
            if self.A <= 3:
                self._theta_bound = _quark_level_bound_thetas(
                    self.P, self.N, self._lattice_base
                )
        else:
            self._theta_bound = np.array([])
            self._binding_energy_mev = 0.0
        _, theta_alpha_arr = _binding_energy_via_network(2, 2, self._lattice_base)
        self._theta_alpha = float(theta_alpha_arr[0]) if len(theta_alpha_arr) > 0 else self._lattice_base * 8.0

        self._E_info_mev = self._compute_E_info_mev()

    def _compute_E_info_mev(self) -> float:
        """E_info = ħc Σ(1/Θ_i) + excitation (MeV)."""
        if self.A <= 0 or len(self._theta_bound) == 0:
            return self.excitation_energy
        hbar_c_mev_m = HBAR_C_MEV_FM * 1e-15
        tension = hbar_c_mev_m * np.sum(1.0 / self._theta_bound)
        return float(tension + self.excitation_energy)

    def theta_stable_m(self) -> float:
        """Effective stable horizon (harmonic mean of bound Θ — direct from 1/Θ energy weighting)."""
        if self.A <= 0 or len(self._theta_bound) == 0:
            return self._lattice_base * 8.0  # so(8) dimension, degenerate case
        return float(self.A / np.sum(1.0 / self._theta_bound))

    def theta_unstable_m(self, source: Optional[str] = None) -> float:
        """Maximum-tension horizon (min Θ), optionally restricted to convertible nucleons."""
        if self.A <= 0 or len(self._theta_bound) == 0:
            return self._lattice_base * 8.0
        if source == "β-":
            mask = ~self._is_proton_bound
            if np.any(mask):
                return float(np.min(self._theta_bound[mask]))
        if source == "β+":
            mask = self._is_proton_bound
            if np.any(mask):
                return float(np.min(self._theta_bound[mask]))
        return float(np.min(self._theta_bound))

    def phi_si(self) -> float:
        """φ = 2 c² / Θ_avg (m²/s²). Paper: φ(x) = 2c²/Θ_local(x)."""
        theta_avg = (self.theta_unstable_m() + self.theta_stable_m()) / 2.0
        return 2.0 * (C_SI**2) / max(theta_avg, 1e-30)

    def _lapse_f(self) -> float:
        """
        Modified inertia f(a_loc, φ) = a_loc / (a_loc + φ/6). Paper particle action.

        Use acceleration scale at the nucleus horizon: a_loc = c²/Θ_avg (so φ = 2a_loc).
        When φ is large (compact nucleus), f < 1 → effective thermal energy for barrier crossing is reduced.
        """
        theta_avg = (self.theta_unstable_m() + self.theta_stable_m()) / 2.0
        theta_avg = max(theta_avg, 1e-30)
        a_loc = (C_SI**2) / theta_avg
        phi = 2.0 * (C_SI**2) / theta_avg
        return float(f_inertia(a_loc, phi))

    @property
    def binding_energy_mev(self) -> float:
        return self._binding_energy_mev

    @property
    def E_info_mev(self) -> float:
        return self._E_info_mev

    # ── Snap energy calculations (pure ΔE = ħc (1/Θ_u – 1/Θ_d …)) ──
    def _delta_E_mev(
        self,
        theta_daughter_stable: float,
        theta_cluster: float = None,
        theta_source: Optional[float] = None,
        conversion_gap_mev: float = 0.0,
    ) -> float:
        """General ΔE_info = ħc (1/Θ_unstable – 1/Θ_daughter – 1/Θ_cluster if present)."""
        theta_u = theta_source if theta_source is not None else self.theta_unstable_m()
        hbar_c_mev_m = HBAR_C_MEV_FM * 1e-15
        de = conversion_gap_mev + hbar_c_mev_m * (
            1.0 / max(theta_u, 1e-30) - 1.0 / max(theta_daughter_stable, 1e-30)
        )
        if theta_cluster is not None:
            de -= hbar_c_mev_m / max(theta_cluster, 1e-30)
        return max(0.0, float(de))

    # ── Allowed relational snaps ──
    def allowed_snaps(self) -> List[Tuple[NuclearConfig, float, str]]:
        snaps = []
        theta_stable = self.theta_stable_m()
        # β⁻: A==1 (free neutron) or quark-driven light nuclei (A≤3) or one neutron with lower Θ
        theta_beta_minus = self.theta_unstable_m("β-")
        has_beta_minus_weak_site = (
            self.A == 1
            or (self.A <= 3 and self.N > 0)  # quark-level: decay driven by quark interactions
            or theta_beta_minus < theta_stable * (1.0 - 1e-9)
        )
        if self.N > 0 and has_beta_minus_weak_site:
            dau = NuclearConfig(self.P + 1, self.N - 1, t_cmb=self.t_cmb)
            de = self._delta_E_mev(
                dau.theta_stable_m(),
                theta_source=theta_beta_minus,
                conversion_gap_mev=self._free_neutron_energy_mev - self._free_proton_energy_mev,
            )
            if de > 0:
                snaps.append((dau, de, "β-"))

        # β⁺
        theta_beta_plus = self.theta_unstable_m("β+")
        has_beta_plus_weak_site = self.A == 1 or theta_beta_plus < theta_stable * (1.0 - 1e-9)
        if self.P > 0 and has_beta_plus_weak_site:
            dau = NuclearConfig(self.P - 1, self.N + 1, t_cmb=self.t_cmb)
            de = self._delta_E_mev(
                dau.theta_stable_m(),
                theta_source=theta_beta_plus,
                conversion_gap_mev=self._free_proton_energy_mev - self._free_neutron_energy_mev,
            )
            if de > 0:
                snaps.append((dau, de, "β+"))

        # α
        if self.P >= 2 and self.N >= 2:
            de = self._delta_E_mev(NuclearConfig(self.P - 2, self.N - 2, t_cmb=self.t_cmb).theta_stable_m(),
                                   self._theta_alpha)
            if de > 0:
                dau = NuclearConfig(self.P - 2, self.N - 2, t_cmb=self.t_cmb)
                snaps.append((dau, de, "α"))

        # Spontaneous fission (symmetric split)
        if self.A >= 60:
            frag = NuclearConfig(self.P // 2, self.N // 2, t_cmb=self.t_cmb)
            de = self._delta_E_mev(frag.theta_stable_m())   # approximate for two fragments
            if de > 0:
                snaps.append(((self.P // 2, self.N // 2), de, "SF"))

        # Cluster (¹⁴C example — add more as needed)
        if self.P >= 6 and self.N >= 8 and self.A >= 180:
            de = self._delta_E_mev(
                NuclearConfig(self.P - 6, self.N - 8, t_cmb=self.t_cmb).theta_stable_m(),
                NuclearConfig(6, 8, t_cmb=self.t_cmb).theta_stable_m()
            )
            if de > 0:
                dau = NuclearConfig(self.P - 6, self.N - 8, t_cmb=self.t_cmb)
                snaps.append((dau, de, "cluster(¹⁴C)"))

        return snaps

    def snap_probability(self, delta_E_info_mev: float) -> float:
        """
        Core HQIV snap probability. Paper: Boltzmann × φ-damping × modified inertia.

        P_snap = exp(-ΔE / kT_eff) × (φ/(φ+φ_crit)), with kT_eff = ħc/Θ × f(a_loc, φ).
        Modified inertia f = a_loc/(a_loc+φ/6) reduces effective thermal energy when φ is large
        (compact nucleus), so barrier crossing is harder — same f as in particle action S = -m c ∫ f ds.
        """
        if delta_E_info_mev <= 0:
            return 0.0
        theta_avg = (self.theta_unstable_m() + self.theta_stable_m()) / 2.0
        theta_avg = max(theta_avg, 1e-30)
        hbar_c_mev_m = HBAR_C_MEV_FM * 1e-15
        kT_horizon = hbar_c_mev_m / theta_avg
        f = self._lapse_f()
        kT_eff = kT_horizon * max(f, 0.01)
        boltzmann = np.exp(-delta_E_info_mev / kT_eff)
        damping = self.phi_si() / max(self.phi_si() + self._phi_crit, 1e-30)
        return float(boltzmann * damping)

    def decay_rate_per_s(self) -> float:
        """
        Total macroscopic decay constant. Paper: λ_obs = (P_snap/τ_tick) × f / scale.

        Observer-time rate includes lapse f (S_particle = -m c ∫ f ds ⇒ dτ = f dt for rate scaling).
        """
        snaps = self.allowed_snaps()
        if not snaps:
            return 0.0
        total_p = sum(self.snap_probability(de) for _, de, _ in snaps)
        f = self._lapse_f()
        lam_raw = total_p / max(self._tau_tick, 1e-50)
        return lam_raw * f / max(self._macro_scale, 1e-30)

    def half_life_s(self) -> Optional[float]:
        """Half-life in seconds (None if stable)."""
        lam = self.decay_rate_per_s()
        return np.log(2.0) / lam if lam > 0 and np.isfinite(lam) else None

    def decay_channel_reports(self) -> List[DecayChannelReport]:
        """
        Per-channel decay rates consistent with :meth:`decay_rate_per_s`.

        Total rate is sum_i λ_i with λ_i = (P_snap_i / τ_tick) × f / scale
        (parallel channels). Branching ratio λ_i / Σ λ_j = P_snap_i / Σ P_snap_j.
        """
        snaps = self.allowed_snaps()
        if not snaps:
            return []
        f = self._lapse_f()
        scale = max(self._macro_scale, 1e-30)
        tick = max(self._tau_tick, 1e-50)
        probs = [self.snap_probability(de) for _, de, _ in snaps]
        total_p = float(sum(probs))
        lam_total = (total_p / tick) * f / scale
        out: List[DecayChannelReport] = []
        for (daughter, de, mode), p_snap in zip(snaps, probs):
            lam_i = (float(p_snap) / tick) * f / scale
            t_half_i = (
                float(np.log(2.0) / lam_i)
                if lam_i > 0 and np.isfinite(lam_i)
                else None
            )
            br = float(lam_i / lam_total) if lam_total > 0 else 0.0
            dP, dN = _daughter_pn_from_snap(daughter)
            out.append(
                DecayChannelReport(
                    mode=mode,
                    daughter_protons=dP,
                    daughter_neutrons=dN,
                    delta_E_info_mev=float(de),
                    snap_probability=float(p_snap),
                    decay_rate_per_s=float(lam_i),
                    half_life_s=t_half_i,
                    branching_ratio=br,
                )
            )
        return out


def _daughter_pn_from_snap(
    daughter: Union[NuclearConfig, Tuple[int, int]],
) -> Tuple[Optional[int], Optional[int]]:
    if isinstance(daughter, NuclearConfig):
        return (daughter.P, daughter.N)
    if isinstance(daughter, tuple) and len(daughter) == 2:
        return (int(daughter[0]), int(daughter[1]))
    return (None, None)


class DecayChannelReport(NamedTuple):
    """One allowed relational snap: daughter (P, N), ΔE_info, and parallel-channel kinetics."""

    mode: str
    daughter_protons: Optional[int]
    daughter_neutrons: Optional[int]
    delta_E_info_mev: float
    snap_probability: float
    decay_rate_per_s: float
    half_life_s: Optional[float]
    branching_ratio: float


class NuclearStructureReport(NamedTuple):
    """Equilibrium-style geometry used for EM / network energies (metres, fm)."""

    mass_number: int
    proton_number: int
    neutron_number: int
    positions_m: np.ndarray
    geometry: str
    r_rms_fm: float


@dataclass(frozen=True)
class NuclearCompositionSpec:
    """User-facing composition; mirrors Lean nucleon-centric layer (protons + neutrons + excitation)."""

    protons: int
    neutrons: int
    excitation_energy_mev: float = 0.0
    extra_baryons: Tuple[Tuple[str, int], ...] = ()

    def __post_init__(self) -> None:
        if self.protons < 0 or self.neutrons < 0:
            raise ValueError("protons and neutrons must be non-negative")
        if self.extra_baryons:
            raise ValueError(
                "extra_baryons must be empty until hypernuclear / exotic baryon "
                "tracks are wired to the same 8×8 network (Lean nucleon layer is "
                "proton/neutron only in NuclearAndAtomicSpectra)."
            )


@dataclass(frozen=True)
class NuclearSystemReport:
    """Full nuclear snapshot: structure, binding variants, and decay table."""

    composition: NuclearCompositionSpec
    structure: NuclearStructureReport
    binding_energy_mev: float
    binding_energy_mev_functional: float
    binding_energy_mev_algebraic: float
    E_info_mev: float
    decay_channels: Tuple[DecayChannelReport, ...]
    total_decay_rate_per_s: float
    half_life_s: Optional[float]
    lean_reference: str


def _geometry_label(A: int, positions_m: np.ndarray) -> str:
    if A <= 0:
        return "empty"
    if A == 1:
        return "single_nucleon"
    if A == 2:
        return "two_body_segment"
    if A == 4:
        return "tetrahedron_candidate"
    return "many_body_minimized"


def _rms_radius_fm(positions_m: np.ndarray) -> float:
    pos = np.asarray(positions_m, dtype=float)
    if pos.size == 0:
        return 0.0
    com = np.mean(pos, axis=0)
    disp = pos - com
    r2 = np.sum(disp * disp, axis=1)
    return float(np.sqrt(np.mean(r2)) * 1e15)


def nuclear_system_report(
    protons: int,
    neutrons: int,
    *,
    excitation_energy_mev: float = 0.0,
    extra_baryons: Optional[Mapping[str, int]] = None,
    name: str = "",
    t_cmb: float = _CMB_K,
    algebra=None,
    structure_source: str = "auto",
) -> NuclearSystemReport:
    """
    Build a full nuclear report from (Z, N) = (protons, neutrons).

    Binding energies: ``binding_energy_mev`` matches :class:`NuclearConfig` (HorizonNetwork
    Θ ladder used for decays). ``binding_energy_mev_functional`` is the gold-standard
    functional path (may be zero while that minimizer path is disabled). Algebraic path
    is phase-lifted fanoplane fusion only.

    Parameters
    ----------
    protons, neutrons
        Proton and neutron counts (Z, N).
    excitation_energy_mev
        Added to E_info (MeV), same as :class:`NuclearConfig` excitation.
    extra_baryons
        Must be empty or omitted; reserved for future Λ, Σ, etc.
    name
        Optional label (not used in physics, only for repr/debug).
    t_cmb
        CMB temperature (K) for horizon constants.
    algebra
        Optional :class:`~pyhqiv.algebra.OctonionHQIVAlgebra` instance.
    structure_source
        ``"auto"`` — use functional positions when non-degenerate, else nucleon minimizer;
        ``"nucleon_min"`` — always :func:`minimize_nucleon_configuration`;
        ``"functional"`` — only :func:`binding_energy_mev_functional` positions.

    Returns
    -------
    NuclearSystemReport
    """
    extra: Tuple[Tuple[str, int], ...] = ()
    if extra_baryons:
        extra = tuple(sorted((str(k), int(v)) for k, v in extra_baryons.items()))
    comp = NuclearCompositionSpec(
        int(protons),
        int(neutrons),
        float(excitation_energy_mev),
        extra_baryons=extra,
    )
    P, N = comp.protons, comp.neutrons
    A = P + N

    func_res = binding_energy_mev_functional(P, N, t_cmb=t_cmb, algebra=algebra)
    B_func = float(func_res.B_mev)
    B_alg = float(binding_energy_mev_algebraic(P, N, t_cmb=t_cmb))

    positions_m = np.asarray(func_res.positions_m, dtype=float).reshape(-1, 3)
    if structure_source == "nucleon_min" and A > 1:
        hbar_c_m = HBAR_C_MEV_FM * 1e-15
        r_p = hbar_c_m / M_PROTON_MEV
        r_n = hbar_c_m / M_NEUTRON_MEV
        radii_m = np.array([r_p] * P + [r_n] * N)
        is_proton_list = [True] * P + [False] * N
        const = get_hqiv_nuclear_constants(t_cmb)
        positions_m = minimize_nucleon_configuration(
            radii_m, is_proton_list, const["LATTICE_BASE_M"], algebra=algebra
        )
    elif structure_source == "auto" and A > 1:
        if np.allclose(positions_m, 0.0):
            hbar_c_m = HBAR_C_MEV_FM * 1e-15
            r_p = hbar_c_m / M_PROTON_MEV
            r_n = hbar_c_m / M_NEUTRON_MEV
            radii_m = np.array([r_p] * P + [r_n] * N)
            is_proton_list = [True] * P + [False] * N
            const = get_hqiv_nuclear_constants(t_cmb)
            positions_m = minimize_nucleon_configuration(
                radii_m, is_proton_list, const["LATTICE_BASE_M"], algebra=algebra
            )
    elif structure_source == "functional":
        pass
    else:
        raise ValueError(
            f"structure_source must be 'auto', 'nucleon_min', or 'functional', got {structure_source!r}"
        )

    geom = _geometry_label(A, positions_m)
    r_rms = _rms_radius_fm(positions_m)
    struct = NuclearStructureReport(
        mass_number=A,
        proton_number=P,
        neutron_number=N,
        positions_m=positions_m.copy(),
        geometry=geom,
        r_rms_fm=r_rms,
    )

    cfg = NuclearConfig(
        P,
        N,
        name=name or f"{P}-{A}",
        excitation_energy=comp.excitation_energy_mev,
        t_cmb=t_cmb,
    )
    channels = tuple(cfg.decay_channel_reports())
    lam_tot = float(cfg.decay_rate_per_s())
    t_half = cfg.half_life_s()

    lean_ref = (
        "Hqiv.Physics.BoundStates (E_bind_nuclear_from_network); "
        "Hqiv.Physics.NuclearAndAtomicSpectra (V_nuclear, half_life_from_width)"
    )

    return NuclearSystemReport(
        composition=comp,
        structure=struct,
        binding_energy_mev=float(cfg.binding_energy_mev),
        binding_energy_mev_functional=B_func,
        binding_energy_mev_algebraic=B_alg,
        E_info_mev=float(cfg.E_info_mev),
        decay_channels=channels,
        total_decay_rate_per_s=lam_tot,
        half_life_s=t_half,
        lean_reference=lean_ref,
    )


# ── Minimal public API (just thin wrappers around NuclearConfig) ──
def delta_E_info_mev(theta_unstable_m: float, theta_stable_m: float) -> float:
    """ΔE_info = ħc (1/Θ_unstable – 1/Θ_stable) in MeV. Θ in metres."""
    if theta_unstable_m <= 0 or theta_stable_m <= 0:
        return 0.0
    hbar_c_mev_m = HBAR_C_MEV_FM * 1e-15
    return hbar_c_mev_m * (1.0 / theta_unstable_m - 1.0 / theta_stable_m)


class BindingResult(NamedTuple):
    """
    Gold-standard binding result from the functional method (self-consistent Θ + minimization).

    Use binding_energy_mev_functional(P, N, t_cmb) to get this. Tests assert against these fields.
    """
    B_mev: float
    E_free_mev: float
    E_bound_mev: float
    positions_m: np.ndarray  # (A, 3) equilibrium positions in metres
    theta_p_m: float
    theta_n_m: float


def _system_energy_terms_mev(
    positions_m: np.ndarray,
    masses_mev: np.ndarray,
    is_proton_list: List[bool],
    algebra=None,
) -> Tuple[float, float, float, float]:
    """
    Two interaction terms and rest mass. E_total = E_mass + E_attraction + E_repulsion + overlap_penalty.

    Term 1 (attraction): from non-EM part of 8×8 only; Casimir-like −w_ij·ħc/d_ij per pair.
    Term 2 (EM): p–p Coulomb repulsion minus p–n hypercharge binding (ζ from 8×8). Solve for x that minimize E_total.
    """
    A = positions_m.shape[0]
    if A == 0:
        return 0.0, 0.0, 0.0, 0.0
    E_mass = float(np.sum(masses_mev))
    hbar_c_fm = HBAR_C_MEV_FM
    radii_fm = np.array([hbar_c_fm / max(m, 1e-30) for m in masses_mev])
    E_attraction = 0.0
    overlap_penalty = 0.0
    for i in range(A):
        for j in range(i + 1, A):
            d_m = float(np.linalg.norm(positions_m[i] - positions_m[j])) + 1e-30
            d_fm = d_m * 1e15
            rsum_fm = radii_fm[i] + radii_fm[j]
            if d_fm < rsum_fm:
                overlap_penalty += 1e6 * (rsum_fm - d_fm) ** 2
            else:
                w_ij = _non_em_fraction_pair(
                    bool(is_proton_list[i]), bool(is_proton_list[j]), algebra=algebra
                )
                E_attraction -= w_ij * (hbar_c_fm / d_fm)
    E_repulsion = opposing_fields_energy_mev(positions_m, is_proton_list, algebra=algebra)
    return (E_mass, E_attraction, E_repulsion, overlap_penalty)


def _system_energy_mev(
    positions_m: np.ndarray,
    masses_mev: np.ndarray,
    is_proton_list: List[bool],
    algebra=None,
) -> float:
    """
    Total system energy (MeV). Two terms: (1) attraction from non-EM 8×8, (2) EM = p–p repulsion − p–n binding.

    Solve for distances x that minimize E. E = E_mass + E_attraction + E_EM (+ overlap penalty).
    E_EM = opposing_fields_energy_mev (p–p Coulomb minus p–n hypercharge binding). No free constants.
    """
    E_mass, E_attraction, E_repulsion, overlap_penalty = _system_energy_terms_mev(
        positions_m, masses_mev, is_proton_list, algebra=algebra
    )
    return E_mass + E_attraction + E_repulsion + overlap_penalty


def _equilibrium_distance_two_nucleons_fm(
    m1_mev: float,
    m2_mev: float,
    is_proton_1: bool,
    is_proton_2: bool,
    algebra=None,
) -> Tuple[float, float, float]:
    """
    Solve for the distance x (fm) between two horizons that minimizes E(x).

    Two terms: E_attraction(x) from non-EM 8×8, E_repulsion(x) from EM. Find x_opt such that
    dE/dx = 0. Returns (x_opt_fm, E_attraction_at_x, E_repulsion_at_x).
    """
    from scipy.optimize import minimize_scalar

    hbar_c_fm = HBAR_C_MEV_FM
    r1_fm = hbar_c_fm / max(m1_mev, 1e-30)
    r2_fm = hbar_c_fm / max(m2_mev, 1e-30)
    x_min_fm = r1_fm + r2_fm
    w = _non_em_fraction_pair(is_proton_1, is_proton_2, algebra=algebra)
    alpha_em = 1.0 / max(ALPHA_EM_INV, 1e-30)
    scale_em = alpha_em * hbar_c_fm
    zeta_pn = 0.0
    if is_proton_1 != is_proton_2:
        if algebra is None:
            from pyhqiv.algebra import OctonionHQIVAlgebra
            algebra = OctonionHQIVAlgebra(verbose=False)
        from pyhqiv.subatomic import nucleon_charge_unwrapped_folded_measures
        m_uud = nucleon_charge_unwrapped_folded_measures("uud", algebra=algebra)
        m_udd = nucleon_charge_unwrapped_folded_measures("udd", algebra=algebra)
        coh_uud = m_uud.get("coherence", 1.0)
        coh_udd = m_udd.get("coherence", 1.0)
        zeta_pn = max(0.0, 1.0 - coh_udd / max(coh_uud, 1e-30))
    # E_EM = E_pp_repulsion − E_pn_binding (p-n hypercharge interaction is attractive)
    pp = 1.0 if (is_proton_1 and is_proton_2) else 0.0
    pn_binding = scale_em * zeta_pn if (is_proton_1 != is_proton_2) else 0.0

    def E_total(x_fm: float) -> float:
        if x_fm < x_min_fm:
            return 1e30 + (x_min_fm - x_fm) ** 2
        E_att = -w * (hbar_c_fm / x_fm)
        E_em = (pp * scale_em - pn_binding) / x_fm
        return E_att + E_em

    res = minimize_scalar(E_total, bounds=(x_min_fm, 1e4), method="bounded")
    x_opt_fm = float(res.x)
    E_att_at_x = -w * (hbar_c_fm / x_opt_fm)
    E_em_at_x = (pp * scale_em - pn_binding) / x_opt_fm
    return (x_opt_fm, E_att_at_x, E_em_at_x)


def equilibrium_distance_two_nucleons_fm(
    m1_mev: float,
    m2_mev: float,
    is_proton_1: bool,
    is_proton_2: bool,
    algebra=None,
) -> Tuple[float, float, float]:
    """
    Two terms and solve for x: find distance x (fm) between two horizons that minimizes E(x).

    Returns (x_opt_fm, E_attraction_mev, E_repulsion_mev) at the energy minimum.
    Term 1 = attraction from non-EM 8×8; term 2 = EM repulsion.
    """
    return _equilibrium_distance_two_nucleons_fm(
        m1_mev, m2_mev, is_proton_1, is_proton_2, algebra=algebra
    )


def system_energy_terms_mev(
    positions_m: np.ndarray,
    masses_mev: np.ndarray,
    is_proton_list: List[bool],
    algebra=None,
) -> Tuple[float, float, float, float]:
    """
    Two interaction terms at given positions. E_total = E_mass + E_attraction + E_repulsion + overlap_penalty.

    Returns (E_mass, E_attraction, E_repulsion, overlap_penalty). Solve for positions (hence
    distances x) that minimize E_total.
    """
    return _system_energy_terms_mev(
        positions_m, masses_mev, is_proton_list, algebra=algebra
    )


def _minimize_system_energy(
    masses_mev: np.ndarray,
    is_proton_list: List[bool],
    algebra=None,
    initial_guess: Optional[np.ndarray] = None,
) -> np.ndarray:
    """
    Solve for equilibrium distances x between horizons: minimize E over positions.

    Two terms: E_attraction (non-EM 8×8) and E_repulsion (EM). Minimum gives equilibrium x.
    Returns positions (metres). Radii from mass: r_i = ħc/(m_i c²).
    """
    from scipy.optimize import minimize

    A = len(masses_mev)
    if A <= 1:
        return np.zeros((A, 3))
    if A == 2:
        x_opt_fm, _, _ = _equilibrium_distance_two_nucleons_fm(
            masses_mev[0], masses_mev[1],
            bool(is_proton_list[0]), bool(is_proton_list[1]),
            algebra=algebra,
        )
        x_opt_m = x_opt_fm * 1e-15
        positions = np.array([[-0.5 * x_opt_m, 0.0, 0.0], [0.5 * x_opt_m, 0.0, 0.0]])
        return positions
    hbar_c_m = HBAR_C_MEV_FM * 1e-15
    radii_m = np.array([hbar_c_m / max(m, 1e-30) for m in masses_mev])
    if initial_guess is None:
        initial_guess = _initial_guess_positions(radii_m, is_proton_list)
    x0 = np.asarray(initial_guess, dtype=float).reshape(A, 3)
    bound_fm = 5.0 * 1e-15
    bounds = [(-bound_fm, bound_fm)] * (A * 3)

    def objective(pos_flat: np.ndarray) -> float:
        positions = pos_flat.reshape(-1, 3)
        return _system_energy_mev(positions, masses_mev, is_proton_list, algebra=algebra)

    res = minimize(
        objective,
        x0.flatten(),
        method="L-BFGS-B",
        bounds=bounds,
        options={"maxiter": 200},
    )
    positions = res.x.reshape(-1, 3)
    positions -= np.mean(positions, axis=0)
    return positions


def binding_energy_mev_functional(
    P: int,
    N: int,
    t_cmb: float = _CMB_K,
    algebra=None,
) -> BindingResult:
    """
    Two terms: (1) attraction from non-EM part of 8×8, (2) EM = p–p repulsion − p–n binding.
    Solve for x that minimize E(x). E_bound = E(positions_opt), B = E_free − E_bound.

    NOTE: The minimizer path is currently disabled (returns B=0) because it produces wrong scale
    (e.g. B ~359 MeV for 2H vs exp 2.22 MeV). See commented block below; re-enable when formulation
    gives MeV-scale B (docs/binding_energy_walkthrough.md §6.5.3).
    """
    from pyhqiv.energy_field import effective_horizon_from_energy_mev
    from pyhqiv.subatomic import neutron_energy_mev, proton_energy_mev

    if P <= 0 and N <= 0:
        return BindingResult(
            B_mev=0.0,
            E_free_mev=0.0,
            E_bound_mev=0.0,
            positions_m=np.zeros((0, 3)),
            theta_p_m=0.0,
            theta_n_m=0.0,
        )

    if algebra is None:
        from pyhqiv.algebra import OctonionHQIVAlgebra
        algebra = OctonionHQIVAlgebra(verbose=False)

    E_p = proton_energy_mev(t_cmb)
    E_n = neutron_energy_mev(t_cmb)
    theta_p = effective_horizon_from_energy_mev(E_p)
    theta_n = effective_horizon_from_energy_mev(E_n)
    masses_mev = np.array([M_PROTON_MEV] * P + [M_NEUTRON_MEV] * N)
    [True] * P + [False] * N
    E_free = float(np.sum(masses_mev))
    A = P + N

    # DISABLED: produces wrong scale (e.g. B ~359 MeV for 2H vs exp 2.22 MeV). Re-enable when
    # attraction/EM formulation gives MeV-scale B (see docs/binding_energy_walkthrough.md §6.5.3).
    # positions = _minimize_system_energy(
    #     masses_mev, is_proton_list, algebra=algebra, initial_guess=None
    # )
    # E_bound = _system_energy_mev(
    #     positions, masses_mev, is_proton_list, algebra=algebra
    # )
    # B = E_free - E_bound

    positions = np.zeros((A, 3))
    E_bound = E_free
    B = 0.0

    return BindingResult(
        B_mev=B,
        E_free_mev=E_free,
        E_bound_mev=E_bound,
        positions_m=positions.copy(),
        theta_p_m=theta_p,
        theta_n_m=theta_n,
    )


def binding_energy_mev(P: int, N: int, t_cmb: float = _CMB_K) -> float:
    """
    Nuclear binding energy B = E_free − E_bound (MeV). Uses gold-standard functional method.

    Returns result.B_mev from binding_energy_mev_functional(P, N, t_cmb). Can be negative
    if E_bound > E_free (unbound in first-principles); tests assert against experiment.
    """
    result = binding_energy_mev_functional(P, N, t_cmb=t_cmb)
    return result.B_mev


def binding_energy_isotope(symbol: str, A: int, t_cmb: float = _CMB_K) -> float:
    """Binding energy (MeV) for any isotope: symbol + mass number (e.g. binding_energy_isotope('C', 14))."""
    P, N = nuclide_from_symbol(symbol, A=A)
    return binding_energy_mev(P, N, t_cmb=t_cmb)


def binding_energy_mev_algebraic(P: int, N: int, t_cmb: float = _CMB_K) -> float:
    """Binding energy (MeV) from phase-lifted fanoplane fusion only (no positions/radii)."""
    const = get_hqiv_nuclear_constants(t_cmb)
    return _binding_energy_via_algebra(P, N, const["LATTICE_BASE_M"], None)[0]


def theta_nuclear_stable_m(P: int, N: int, t_cmb: float = _CMB_K) -> float:
    return NuclearConfig(P, N, t_cmb=t_cmb).theta_stable_m()


def theta_nuclear_unstable_m(P: int, N: int, t_cmb: float = _CMB_K) -> float:
    return NuclearConfig(P, N, t_cmb=t_cmb).theta_unstable_m()


def half_life_nuclide_hqiv(P: int, N: int, t_cmb: float = _CMB_K) -> Optional[float]:
    return NuclearConfig(P, N, t_cmb=t_cmb).half_life_s()


def decay_chain(P: int, N: int, max_steps: int = 20, t_cmb: float = _CMB_K) -> List[Tuple[int, int]]:
    chain = [(P, N)]
    current = NuclearConfig(P, N, t_cmb=t_cmb)
    for _ in range(max_steps - 1):
        snaps = current.allowed_snaps()
        if not snaps:
            break
        probs = [current.snap_probability(de) for _, de, _ in snaps]
        idx = int(np.argmax(probs))
        daughter, _, _ = snaps[idx]
        if isinstance(daughter, tuple):
            chain.append(daughter)
            current = NuclearConfig(*daughter, t_cmb=t_cmb)
        else:
            chain.append((daughter.P, daughter.N))
            current = daughter
    return chain


def decay_chain_nuclide_hqiv(
    P: int, N: int, max_steps: int = 20, t_cmb: float = _CMB_K
) -> Tuple[Optional[float], str, Optional[int], Optional[int], List[Tuple[int, int]]]:
    cfg = NuclearConfig(P, N, t_cmb=t_cmb)
    t_half = cfg.half_life_s()
    chain = decay_chain(P, N, max_steps, t_cmb)
    if len(chain) < 2:
        return t_half, "stable", None, None, chain
    dP, dN = chain[1]
    snaps = cfg.allowed_snaps()
    if not snaps:
        return t_half, "?", dP, dN, chain
    probs = [cfg.snap_probability(de) for _, de, _ in snaps]
    idx = int(np.argmax(probs))
    mode = snaps[idx][2]
    return t_half, mode, dP, dN, chain


# ── Optional pint for public API unit conversion (internal units stay natural: s, MeV) ──
try:
    from pint import UnitRegistry
    _ureg = UnitRegistry()
    _ureg.default_format = "~P"
except ImportError:
    _ureg = None


class Nuclide:
    """
    User-facing wrapper around HQIV NuclearConfig.
    Accepts natural-language identifiers; returns quantities in human-readable units when pint is installed.
    Internal package units are natural (s, MeV); unit conversion happens at this API boundary.
    """

    def __init__(
        self,
        identifier: Union[str, int, Tuple[int, int]],
        t_cmb: float = _CMB_K,
        neutrino_flux: float = 6.5e10,
    ) -> None:
        self.t_cmb = float(t_cmb)
        self.neutrino_flux = float(neutrino_flux)
        P, N = self._parse_identifier(identifier)
        self.P = P
        self.N = N
        self.A = P + N
        self.symbol = self._get_symbol(P) or f"Z{P}"
        self._cfg = NuclearConfig(
            P, N,
            name=f"{self.symbol}-{self.A}",
            t_cmb=self.t_cmb,
        )

    @staticmethod
    def _parse_identifier(s: Union[str, int, Tuple[int, int]]) -> Tuple[int, int]:
        if isinstance(s, tuple) and len(s) == 2:
            return int(s[0]), int(s[1])
        if isinstance(s, int):
            A = s
            for sym, (p, ndef) in _ELEMENT_PN.items():
                if p + ndef == A:
                    return p, ndef
            raise ValueError(f"Unknown mass number {A}. Use e.g. 'U-238' or (92, 146).")
        s_clean = str(s).strip().replace(" ", "")
        # Z-A with hyphen: "92-238"
        m = re.match(r"^(\d+)-(\d+)$", s_clean)
        if m:
            P, A = int(m.group(1)), int(m.group(2))
            N = A - P
            if N >= 0:
                return P, N
        s = s_clean.lower().replace("-", "")
        # Element + mass: "u238", "238u", "helium4", "carbon14", "C-14"
        m = re.match(r"^(\d+)?([a-z]+)(\d+)?$", s)
        if m:
            num1, elem, num2 = m.groups()
            mass = int(num1 or num2 or 0)
            sym = _ELEMENT_NAME_TO_SYMBOL.get(elem) or (elem[0].upper() + elem[1:].lower() if len(elem) >= 1 else elem.upper())
            P = ELEMENT_SYMBOL_TO_Z.get(sym) or _ELEMENT_PN.get(sym, (0, 0))[0]
            if P == 0:
                raise ValueError(f"Unknown element '{elem}'. Use symbol (C, U, ...) or name (carbon, uranium).")
            if mass == 0:
                mass = P + (_ELEMENT_PN.get(sym, (P, P))[1])
            N = mass - P
            if N >= 0:
                return P, N
        raise ValueError(
            f"Could not parse nuclide '{s}'. Try 'U-238', 'He-4', 'C-14', 'carbon-14', or (P, N)."
        )

    @staticmethod
    def _get_symbol(Z: int) -> Optional[str]:
        return ELEMENT_Z_TO_SYMBOL.get(Z)

    @property
    def half_life(self):
        """Half-life. With pint: Quantity (e.g. .to('yr')); without pint: float seconds or inf."""
        hl_s = self._cfg.half_life_s()
        if hl_s is None or hl_s <= 0:
            if _ureg is not None:
                return _ureg.Quantity(float("inf"), "s")
            return float("inf")
        if _ureg is not None:
            return _ureg.Quantity(hl_s, "s")
        return hl_s

    @property
    def binding_energy(self):
        """Binding energy. With pint: Quantity (MeV); without pint: float MeV."""
        if _ureg is not None:
            return _ureg.Quantity(self._cfg.binding_energy_mev, "MeV")
        return self._cfg.binding_energy_mev

    @property
    def binding_energy_per_nucleon(self):
        """Binding energy per nucleon. With pint: Quantity; without pint: float MeV."""
        be = self.binding_energy
        if _ureg is not None and hasattr(be, "magnitude"):
            return be / self.A
        return be / self.A

    @property
    def E_info(self):
        """E_info from lattice. With pint: Quantity (MeV); without pint: float MeV."""
        if _ureg is not None:
            return _ureg.Quantity(self._cfg.E_info_mev, "MeV")
        return self._cfg.E_info_mev

    def decay_chain(self, max_steps: int = 20) -> List[Nuclide]:
        """Chain of Nuclide instances (same t_cmb, neutrino_flux)."""
        raw = decay_chain(self.P, self.N, max_steps, t_cmb=self.t_cmb)
        return [
            Nuclide((p, n), t_cmb=self.t_cmb, neutrino_flux=self.neutrino_flux)
            for p, n in raw
        ]

    def __repr__(self) -> str:
        hl = self.half_life
        if _ureg is not None and hasattr(hl, "to"):
            yr = hl.to("yr").magnitude
        else:
            yr = hl / (365.25 * 24 * 3600) if hl != float("inf") else float("inf")
        unit = "yr"
        return f"<Nuclide {self.symbol}-{self.A}  t½≈{yr:.3g} {unit}>"


__all__ = [
    "BindingResult",
    "DecayChannelReport",
    "NuclearCompositionSpec",
    "NuclearStructureReport",
    "NuclearSystemReport",
    "ELEMENT_SYMBOL_TO_Z",
    "ELEMENT_Z_TO_SYMBOL",
    "nuclide_from_symbol",
    "NuclearConfig",
    "Nuclide",
    "nuclear_system_report",
    "delta_E_info_mev",
    "equilibrium_distance_two_nucleons_fm",
    "binding_energy_mev_from_r_eq_discrete",
    "positions_at_r_eq_discrete",
    "nuclear_composite_energy_mev",
    "opposing_fields_energy_mev",
    "system_energy_terms_mev",
    "binding_energy_mev",
    "binding_energy_mev_functional",
    "binding_energy_mev_nucleon_level",
    "binding_energy_mev_quark_level",
    "binding_energy_isotope",
    "binding_energy_mev_algebraic",
    "build_nucleon_matrix_with_phase",
    "theta_nuclear_stable_m",
    "theta_nuclear_unstable_m",
    "half_life_nuclide_hqiv",
    "decay_chain",
    "decay_chain_nuclide_hqiv",
    "minimize_nucleon_configuration",
]
