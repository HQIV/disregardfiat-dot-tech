"""
Curvature-binding Earth corrections for the outside ledger.

When the full HQIV_LEAN ``hqiv_curvature_binding_core`` spine is on ``PYTHONPATH``,
this module delegates to it.  Otherwise it exposes the portable ``K`` scaling API
from ``pyhqiv.outside_closure``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from pyhqiv.outside_closure import (
    LabOutsideEnvironment,
    OutsideClosureK,
    apply_outside_closure_k_to_outside_binding,
    default_earth_lab_environment,
    earth_outside_closure_k,
)

ChartKind = Literal["mass", "ambient"]


@dataclass(frozen=True)
class EarthCorrectedOutsideBinding:
    outside_mev_chart: float
    outside_mev_earth: float
    inside_mev: float
    total_mev_chart: float
    total_mev_earth: float
    outside_closure_k: float
    chart: ChartKind

    def to_dict(self) -> dict[str, float | str]:
        return {
            "chart": self.chart,
            "inside_mev": self.inside_mev,
            "outside_mev_chart": self.outside_mev_chart,
            "outside_mev_earth": self.outside_mev_earth,
            "total_mev_chart": self.total_mev_chart,
            "total_mev_earth": self.total_mev_earth,
            "outside_closure_k": self.outside_closure_k,
        }


def earth_corrected_cluster_outside(
    inside_mev: float,
    outside_mev_chart: float,
    *,
    chart: ChartKind = "mass",
    env: LabOutsideEnvironment | None = None,
) -> EarthCorrectedOutsideBinding:
    """Scale only the outside ledger; inside trapped curvature stays on the lock-in chart."""
    env = env or default_earth_lab_environment()
    k = (
        env.outside_closure_k_mass_chart()
        if chart == "mass"
        else env.outside_closure_k_ambient()
    )
    outside_earth = apply_outside_closure_k_to_outside_binding(
        outside_mev_chart, env=env, chart=chart
    )
    return EarthCorrectedOutsideBinding(
        outside_mev_chart=outside_mev_chart,
        outside_mev_earth=outside_earth,
        inside_mev=inside_mev,
        total_mev_chart=inside_mev + outside_mev_chart,
        total_mev_earth=inside_mev + outside_earth,
        outside_closure_k=k,
        chart=chart,
    )


def try_build_curvature_row_earth(
    a: int,
    z: int,
    label: str,
    *,
    earth_mass_chart: bool = True,
) -> dict | None:
    """
    Optional bridge to HQIV_LEAN ``hqiv_curvature_binding_program`` when co-installed.
    Returns ``None`` if the Lean mirror scripts are not importable.
    """
    try:
        import hqiv_curvature_binding_program as cbp
    except ImportError:
        return None
    row = cbp.build_curvature_row(
        a, z, label, earth_mass_chart=earth_mass_chart
    )
    return {
        "label": row.label,
        "A": row.A,
        "Z": row.Z,
        "inside_mev": row.inside_mev,
        "outside_mev_chart": row.outside_mev_chart,
        "outside_mev_earth": row.outside_mev,
        "total_mev_chart": row.total_curvature_mev_chart,
        "total_mev_earth": row.total_curvature_mev,
        "outside_closure_k_mass_chart": row.outside_closure_k_mass_chart,
    }


__all__ = [
    "ChartKind",
    "EarthCorrectedOutsideBinding",
    "LabOutsideEnvironment",
    "OutsideClosureK",
    "apply_outside_closure_k_to_outside_binding",
    "default_earth_lab_environment",
    "earth_corrected_cluster_outside",
    "earth_outside_closure_k",
    "try_build_curvature_row_earth",
]
