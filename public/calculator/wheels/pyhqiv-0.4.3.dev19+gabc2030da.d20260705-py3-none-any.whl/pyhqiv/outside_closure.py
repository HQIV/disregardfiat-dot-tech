"""
Earth-scale outside-closure factor K = B_curv(ξ) × f_g(ε).

Mirrors ``HQIV_LEAN/scripts/hqiv_nuclear_outside_temperature_dynamics.py`` and
``hqiv_earth_outside_closure.py``.

Universe age books through ξ = T_Pl/(k_B T).  Gravity well books through the
weak-field stack ε = Σ GM/(Rc²) + v_dipole/c folded into outside G_eff support.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from typing import Literal

from pyhqiv.lightcone import alpha
from pyhqiv.metric import gamma_hqiv
from pyhqiv.scale_witness import load_local_conditions, local_cmb_temperature_K

GravityBindingTier = Literal["none", "earth", "solar_system", "full"]


def _local() -> dict:
    return load_local_conditions()


def reference_m() -> int:
    from pyhqiv.lightcone import reference_m as _reference_m

    return _reference_m()


def xi_lockin() -> float:
    return float(reference_m() + 1)


def t_pl_mev() -> float:
    return float(_local()["E_PL_MEV_local"])


def k_b_mev_per_k() -> float:
    return float(_local().get("k_B_MeV_per_K", 8.617333262e-11))


def c_light_m_s() -> float:
    return float(_local()["c_si"])


def xi_from_temperature_k(t_k: float) -> float:
    if t_k <= 0.0:
        raise ValueError("temperature must be positive")
    return t_pl_mev() / (k_b_mev_per_k() * t_k)


def gravitational_phi_epsilon(gm_m3_s2: float, radius_m: float) -> float:
    c = c_light_m_s()
    if gm_m3_s2 <= 0.0 or radius_m <= 0.0:
        return 0.0
    return gm_m3_s2 / (radius_m * c * c)


def earth_surface_phi_epsilon() -> float:
    g = _local()["earth_gravity_witness"]
    return float(g["earth_phi_epsilon"])


def solar_phi_epsilon_at_1au() -> float:
    g = _local()["earth_gravity_witness"]
    return float(g["sun_phi_epsilon_at_1au"])


def galactic_circular_phi_epsilon() -> float:
    g = _local()["earth_gravity_witness"]
    return float(g["galactic_phi_epsilon"])


def local_lab_gravity_phi_epsilon(tier: GravityBindingTier = "full") -> float:
    earth = earth_surface_phi_epsilon() if tier in ("earth", "solar_system", "full") else 0.0
    sun = solar_phi_epsilon_at_1au() if tier in ("solar_system", "full") else 0.0
    galaxy = galactic_circular_phi_epsilon() if tier == "full" else 0.0
    return earth + sun + galaxy


def outside_gravity_geff_modulator(phi_epsilon: float) -> float:
    if phi_epsilon <= 0.0:
        return 1.0
    a = alpha()
    g = gamma_hqiv()
    geff_ratio = (1.0 + phi_epsilon) ** a
    return 1.0 + g * (geff_ratio - 1.0)


def curvature_budget_at_xi(xi: float, *, xi_lock: float | None = None) -> float:
    """B_curv(ξ): delegate to HQIV_LEAN when available, else packaged witness chart."""
    xi_lock = xi_lock if xi_lock is not None else xi_lockin()
    try:
        import hqiv_lean_physics_primitives as lean  # type: ignore[import-not-found]

        return float(lean.curvature_budget_at_xi(xi, xi_lock))
    except ImportError:
        pass
    w = _local().get("outside_closure_witness", {})
    if abs(xi - xi_lock) < 1e-9:
        return float(w.get("B_curv_lock", 1.0))
    g = _local()["earth_gravity_witness"]
    xi_cmb = xi_from_temperature_k(local_cmb_temperature_K())
    xi_amb = xi_from_temperature_k(float(g["lab_room_temperature_K"]))
    if abs(math.log(xi / xi_cmb)) < 0.05:
        return float(w.get("B_curv_cmb", 0.834032))
    if abs(math.log(xi / xi_amb)) < 0.05:
        return float(w.get("B_curv_ambient_300K", 0.834926))
    if xi > xi_lock * 100.0:
        return float(w.get("B_curv_ambient_300K", 0.834926))
    gap = 1.0 / max(xi, 1e-30)
    gap0 = 1.0 / xi_lock
    gap_ratio = (2.0 * math.sqrt(gap * gap0)) / max(gap + gap0, 1e-30)
    return max(min(gap_ratio, 4.0), 1e-6)


def _outside_curvature_binding_modulator_fallback(xi: float, *, bonded: bool) -> float:
    _ = bonded
    return curvature_budget_at_xi(xi)


def outside_curvature_binding_modulator(xi: float, *, bonded: bool) -> float:
    """Temperature-branch outside modulator at ξ."""
    try:
        import hqiv_nuclear_outside_temperature_dynamics as notd  # type: ignore[import-not-found]

        return float(notd.outside_curvature_binding_modulator(xi, bonded=bonded))
    except ImportError:
        return _outside_curvature_binding_modulator_fallback(xi, bonded=bonded)


def outside_closure_k_at(
    xi: float,
    phi_gravity_epsilon: float,
    *,
    xi_lock: float | None = None,
) -> float:
    return curvature_budget_at_xi(xi, xi_lock=xi_lock) * outside_gravity_geff_modulator(
        phi_gravity_epsilon
    )


@dataclass(frozen=True)
class LabOutsideEnvironment:
    lab_temperature_k: float
    reference_temperature_k: float
    gravity_tier: GravityBindingTier = "full"
    cmb_dipole_velocity_m_s: float = 0.0
    anchor_xi: float | None = None
    lab_xi: float | None = None

    @property
    def cmb_proper_motion_v_over_c(self) -> float:
        return self.cmb_dipole_velocity_m_s / c_light_m_s()

    @property
    def lab_xi_from_temperature(self) -> float:
        if self.lab_xi is not None:
            return self.lab_xi
        return xi_from_temperature_k(self.lab_temperature_k)

    @property
    def reference_xi_from_temperature(self) -> float:
        return xi_from_temperature_k(self.reference_temperature_k)

    @property
    def anchor_xi_value(self) -> float:
        return self.anchor_xi if self.anchor_xi is not None else xi_lockin()

    @property
    def gravity_phi_epsilon(self) -> float:
        return local_lab_gravity_phi_epsilon(self.gravity_tier)

    @property
    def combined_phi_epsilon(self) -> float:
        return self.gravity_phi_epsilon + self.cmb_proper_motion_v_over_c

    def outside_closure_k_mass_chart(self) -> float:
        return outside_closure_k_at(
            self.anchor_xi_value,
            self.combined_phi_epsilon,
            xi_lock=self.anchor_xi_value,
        )

    def outside_closure_k_ambient(self) -> float:
        return outside_closure_k_at(
            self.lab_xi_from_temperature,
            self.combined_phi_epsilon,
            xi_lock=self.anchor_xi_value,
        )


@dataclass(frozen=True)
class OutsideClosureK:
    xi_lock: float
    xi_ambient: float
    xi_cmb: float
    b_curv_lock: float
    b_curv_ambient: float
    b_curv_cmb: float
    f_gravity: float
    f_kinetic: float
    f_gravity_combined: float
    k_mass_chart: float
    k_ambient: float
    k_cmb: float
    gravity_phi_epsilon: float
    cmb_proper_motion_v_over_c: float

    def to_dict(self) -> dict[str, float]:
        return asdict(self)


def default_earth_lab_environment() -> LabOutsideEnvironment:
    g = _local()["earth_gravity_witness"]
    return LabOutsideEnvironment(
        lab_temperature_k=float(g["lab_room_temperature_K"]),
        reference_temperature_k=local_cmb_temperature_K(),
        gravity_tier="full",
        cmb_dipole_velocity_m_s=float(g["cmb_dipole_v_m_s"]),
    )


def earth_outside_closure_k(
    env: LabOutsideEnvironment | None = None,
) -> OutsideClosureK:
    env = env or default_earth_lab_environment()
    xi_lock = env.anchor_xi_value
    xi_amb = env.lab_xi_from_temperature
    xi_cmb = env.reference_xi_from_temperature
    b_lock = curvature_budget_at_xi(xi_lock, xi_lock=xi_lock)
    b_amb = curvature_budget_at_xi(xi_amb, xi_lock=xi_lock)
    b_cmb = curvature_budget_at_xi(xi_cmb, xi_lock=xi_lock)
    f_grav = outside_gravity_geff_modulator(env.gravity_phi_epsilon)
    f_kin = outside_gravity_geff_modulator(env.cmb_proper_motion_v_over_c)
    f_combined = outside_gravity_geff_modulator(env.combined_phi_epsilon)
    return OutsideClosureK(
        xi_lock=xi_lock,
        xi_ambient=xi_amb,
        xi_cmb=xi_cmb,
        b_curv_lock=b_lock,
        b_curv_ambient=b_amb,
        b_curv_cmb=b_cmb,
        f_gravity=f_grav,
        f_kinetic=f_kin,
        f_gravity_combined=f_combined,
        k_mass_chart=b_lock * f_combined,
        k_ambient=b_amb * f_combined,
        k_cmb=b_cmb * f_combined,
        gravity_phi_epsilon=env.gravity_phi_epsilon,
        cmb_proper_motion_v_over_c=env.cmb_proper_motion_v_over_c,
    )


def apply_outside_closure_k_to_outside_binding(
    outside_binding_mev: float,
    *,
    env: LabOutsideEnvironment | None = None,
    chart: Literal["mass", "ambient"] = "mass",
) -> float:
    env = env or default_earth_lab_environment()
    k = (
        env.outside_closure_k_mass_chart()
        if chart == "mass"
        else env.outside_closure_k_ambient()
    )
    return outside_binding_mev * k


__all__ = [
    "GravityBindingTier",
    "LabOutsideEnvironment",
    "OutsideClosureK",
    "apply_outside_closure_k_to_outside_binding",
    "curvature_budget_at_xi",
    "default_earth_lab_environment",
    "earth_outside_closure_k",
    "outside_closure_k_at",
    "outside_gravity_geff_modulator",
    "xi_from_temperature_k",
    "xi_lockin",
]
