"""
Bonded horizons: joint vs separated perturbed Casimir surplus.

Lean: ``Hqiv/Geometry/BondedHorizonCasimir.lean``

Surplus ``P(N_total) − P(N₁) − P(N₂)`` on the S⁷ metahorizon ladder (dimensionless
λ-units only). eV readout with hydrogen IP anchors lives outside src (tests/scripts).
"""

from __future__ import annotations

from pyhqiv.nuclear_torus_perturbation import DEFAULT_UUD_ANGLES_RAD, perturbed_casimir_energy


def bond_horizon_surplus_dimless(
    n_total: int,
    n_frag1: int,
    n_frag2: int,
    angles: tuple[float, float, float] = DEFAULT_UUD_ANGLES_RAD,
) -> float:
    """Lean ``bondHorizonSurplusDimless``."""
    return (
        perturbed_casimir_energy(n_total, angles)
        - perturbed_casimir_energy(n_frag1, angles)
        - perturbed_casimir_energy(n_frag2, angles)
    )


def ionic_bond_surplus_dimless(
    n_frag1: int,
    n_frag2: int,
    angles: tuple[float, float, float] = DEFAULT_UUD_ANGLES_RAD,
) -> float:
    """Lean ``ionicBondSurplusDimless``."""
    return bond_horizon_surplus_dimless(n_frag1 + n_frag2, n_frag1, n_frag2, angles)


def covalent_dimer_two_electron_surplus_dimless(
    angles: tuple[float, float, float] = DEFAULT_UUD_ANGLES_RAD,
) -> float:
    """Lean ``covalentDimerTwoElectronSurplusDimless`` (H₂-style 2,1,1)."""
    return bond_horizon_surplus_dimless(2, 1, 1, angles)


def metallic_peel_surplus_dimless(
    n_bulk: int,
    n_peel: int,
    angles: tuple[float, float, float] = DEFAULT_UUD_ANGLES_RAD,
) -> float:
    """Lean ``metallicPeelSurplusDimless`` — delocalized bulk vs localized peel."""
    return bond_horizon_surplus_dimless(n_bulk + n_peel, n_bulk, n_peel, angles)


def first_dissociation_two_electron_surplus_dimless(
    angles: tuple[float, float, float] = DEFAULT_UUD_ANGLES_RAD,
) -> float:
    return covalent_dimer_two_electron_surplus_dimless(angles)
