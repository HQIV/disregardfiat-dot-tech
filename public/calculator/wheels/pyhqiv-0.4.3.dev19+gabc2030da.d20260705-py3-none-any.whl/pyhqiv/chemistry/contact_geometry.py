"""
Contact geometry slots shared by ionic / metallic / covalent networks.

Dimensionless ladder units only — ``R_m(m)/Z`` contact radius, ``α``, ``γ``, ``4/8``.
No Bohr radius, no eV anchors, no witness length scales in src.
"""

from __future__ import annotations

from pyhqiv.hqiv_nuclear_spectra import R_m
from pyhqiv.lightcone import alpha
from pyhqiv.metric import gamma_hqiv


def strong_channel_fraction() -> float:
    """Lean ``strongChannelFraction`` (= 4/8)."""
    return 4.0 / 8.0


def constructive_valley_cap() -> float:
    """Lean ``constructiveValleyCap`` (= 6)."""
    return 6.0


def dynamic_contact_radius_dimless(m_s: int, z: int) -> float:
    """
    Lean ``dynamicContactRadiusDimless × alphaEffAtShell ≈ R_m(m)/Z``.

    Natural-unit contact radius on the Compton shell ``m_s`` and nuclear charge ``Z``.
    """
    if m_s < 0:
        raise ValueError("m_s must be non-negative")
    if z <= 0:
        raise ValueError("Z must be positive")
    return R_m(m_s) / float(z)


def horizon_contact_weight(separation_over_contact_radius: float) -> float:
    """
    Lean ``ionicLatticeContactWeight`` / ``metallicLatticeContactWeight`` slot:

    ``1 / (1 + d/r_contact)`` with ``d/r_contact`` supplied directly (dimensionless).
    """
    d = max(float(separation_over_contact_radius), 0.0)
    return 1.0 / (1.0 + d)


def melt_motif_relative_scale_ionic(n_coord: int) -> float:
    """Lean ``meltMotifRelativeScaleIonicLattice``: ``(α/γ)/n``."""
    n = max(n_coord, 1)
    return alpha() / gamma_hqiv() / float(n)


def melt_motif_relative_scale_metallic(n_coord: int) -> float:
    """Lean ``meltMotifRelativeScaleMetallicLattice``: ``(γ/α)/n``."""
    n = max(n_coord, 1)
    return gamma_hqiv() / alpha() / float(n)


def ionic_melt_density_ratio_from_weights(
    lattice_weight: float,
    contact_lock: float,
    n_coord: int,
) -> float:
    """
    Lean ``ionicMeltDensityRatio`` skeleton.

    ``max(γ/4, 1 − motifScale · lock · (1 − weight))``.
    """
    motif = melt_motif_relative_scale_ionic(n_coord)
    lock = min(1.0, max(0.0, contact_lock))
    return max(gamma_hqiv() / 4.0, 1.0 - motif * lock * (1.0 - lattice_weight))


def metallic_melt_density_ratio_from_weights(
    lattice_weight: float,
    contact_lock: float,
    n_coord: int,
) -> float:
    motif = melt_motif_relative_scale_metallic(n_coord)
    lock = min(1.0, max(0.0, contact_lock))
    return max(gamma_hqiv() / 4.0, 1.0 - motif * lock * (1.0 - lattice_weight))


def surplus_reference_floor() -> float:
    """Small dimensionless floor for contact-lock ratios (``4/8 / constructiveValleyCap``)."""
    return strong_channel_fraction() / constructive_valley_cap()
