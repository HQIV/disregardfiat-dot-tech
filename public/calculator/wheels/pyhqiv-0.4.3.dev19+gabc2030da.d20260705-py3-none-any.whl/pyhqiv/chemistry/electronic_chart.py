"""
Electronic valence shells from the TUFT chart.

Lean: ``Hqiv/QuantumChemistry/ElectronicValenceFromTuftChart.lean``

Compton slots are **not** nuclear ``m_nuc(A)``; they are chart rows plus the
proton-anchor hydrogen rung ``m = 1``.
"""

from __future__ import annotations

from pyhqiv.lightcone import reference_m


def tuft_heavy_chart_shell() -> int:
    """Lean ``tuftHeavyChartShell`` / ``electronicComptonCentreS`` (= 4)."""
    return int(reference_m())


def tuft_strong_chart_shell() -> int:
    """Lean ``tuftStrongChartShell`` / ``electronicComptonCentreP`` (= 3)."""
    return int(reference_m()) - 1


def electronic_compton_hydrogen_s() -> int:
    """Lean ``electronicComptonHydrogenS``."""
    return 1


def chemical_period(z: int) -> int:
    """Principal period from nuclear charge (chart bookkeeping, no tables)."""
    if z <= 2:
        return 1
    if z <= 10:
        return 2
    if z <= 18:
        return 3
    if z <= 36:
        return 4
    if z <= 54:
        return 5
    return 6 + (z - 54 - 1) // 18


def electronic_compton_period_offset(period: int) -> int:
    """Lean ``electronicComptonPeriodOffset``."""
    return 0 if period <= 2 else period - 2


def electronic_compton_shells(z: int) -> tuple[int, int | None]:
    """
    Valence (m_s, m_p) Compton indices.

    Period 2 uses ``(4, 3)``; each subsequent period steps one rung on the TUFT chart.
    """
    if z <= 1:
        return electronic_compton_hydrogen_s(), None
    period = chemical_period(z)
    off = electronic_compton_period_offset(period)
    return tuft_heavy_chart_shell() + off, tuft_strong_chart_shell() + off


def valence_electron_count(z: int) -> int:
    """Valence electrons outside the previous noble-gas core."""
    if z <= 2:
        return z
    if z <= 10:
        return z - 2
    if z <= 18:
        return z - 10
    if z <= 36:
        return z - 18
    if z <= 54:
        return z - 36
    return z - 54


def metal_bulk_peel_partition(z: int, electrons: int | None = None) -> tuple[int, int]:
    """
    Metallic peel narrative: ``(n_bulk, n_peel)`` for neutral atom by default.

    ``n_bulk`` = valence (delocalized); ``n_peel`` = inert core (localized).
    """
    e = electrons if electrons is not None else z
    n_bulk = max(valence_electron_count(z), 1)
    n_peel = max(e - n_bulk, 0)
    return n_bulk, n_peel
