"""
Metallic contact slot on the curvature contact network.

Lean:
  • ``Hqiv/Geometry/BondedHorizonCasimir.metallicPeelSurplus``
  • ``Hqiv/QuantumChemistry.MetallicContactSlot.lean``
  • ``Hqiv/QuantumChemistry/PhaseGeometryDensity.metallicMeltDensityRatio``

All readouts dimensionless (λ-units + ``R_m/Z`` separations). No eV / Å anchors.
"""

from __future__ import annotations

from pyhqiv.auxiliary_field import phi_of_shell
from pyhqiv.bonded_horizon_casimir import (
    bond_horizon_surplus_dimless,
    metallic_peel_surplus_dimless,
)
from pyhqiv.chemistry.contact_geometry import (
    constructive_valley_cap,
    dynamic_contact_radius_dimless,
    horizon_contact_weight,
    metallic_melt_density_ratio_from_weights,
    strong_channel_fraction,
    surplus_reference_floor,
)
from pyhqiv.chemistry.electronic_chart import (
    chemical_period,
    electronic_compton_shells,
    metal_bulk_peel_partition,
    valence_electron_count,
)
from pyhqiv.lightcone import alpha
from pyhqiv.metric import gamma_hqiv

# Simple metals on the delocalized-peel spine (translation layer — element class).
_SIMPLE_METAL_Z = frozenset({3, 11, 19, 37, 4, 12, 20, 13, 29, 30})
_ALKALI_Z = frozenset({3, 11, 19, 37, 55})


def is_metallic_element(z: int) -> bool:
    return z in _SIMPLE_METAL_Z


def metallic_coordination(z: int) -> int:
    """BCC alkali (8) vs FCC close-packed default (12)."""
    return 8 if z in _ALKALI_Z else 12


def metallic_valence_merge_surplus_dimless(z: int) -> float:
    """Symmetric valence merge ``bondHorizonSurplus(2·n_val, n_val, n_val)``."""
    n = max(valence_electron_count(z), 1)
    return bond_horizon_surplus_dimless(2 * n, n, n)


def homonuclear_bond_equilibrium_dimless(z: int) -> float:
    """
    Homonuclear equilibrium separation in ladder units (``R_m/Z`` scale).

    Mirrors HQIV nested-WF routing without Å conversion.
    """
    m_s, _ = electronic_compton_shells(z)
    r_cov = dynamic_contact_radius_dimless(m_s, z)
    mono = 1.0 - alpha() / 2.0
    base = 2.0 * r_cov / mono
    cap = constructive_valley_cap()
    strong = strong_channel_fraction()
    if z == 1:
        return base
    if valence_electron_count(z) <= 1:
        return base * (1.0 + strong / cap)
    return base


def metallic_nearest_neighbor_separation_dimless(z: int) -> float:
    """
    Nearest-neighbor separation / ``r_contact`` (dimensionless).

    Close-packing dress from ``φ(m)``, period, and coordination — no tabulated lengths.
    """
    m_s, _ = electronic_compton_shells(z)
    r_contact = dynamic_contact_radius_dimless(m_s, z)
    n_coord = metallic_coordination(z)
    period = chemical_period(z)
    pack = (float(n_coord) / 2.0) ** (1.0 / 3.0)
    cap = constructive_valley_cap()
    phi_dress = phi_of_shell(m_s)
    homo_sep = homonuclear_bond_equilibrium_dimless(z) * (1.0 + gamma_hqiv() / 8.0)
    homo_over_r = homo_sep / max(r_contact, 1e-30)
    if z in _ALKALI_Z and period <= 2:
        return homo_over_r
    lattice_over_r = (
        (1.0 / phi_dress)
        * pack
        * (1.0 + alpha())
        * 2.0
        * (float(period) ** 2 / cap)
    )
    return max(homo_over_r, lattice_over_r)


def metallic_lattice_contact_weight(separation_over_contact_radius: float) -> float:
    return horizon_contact_weight(separation_over_contact_radius)


def metallic_lattice_binding_dimless_per_contact(
    z: int,
    *,
    separation_over_contact_radius: float | None = None,
    coordination: int | None = None,
    electrons: int | None = None,
) -> float:
    """Peel + valence-merge surplus × lattice × coordination dress × valence fraction."""
    sep = (
        separation_over_contact_radius
        if separation_over_contact_radius is not None
        else metallic_nearest_neighbor_separation_dimless(z)
    )
    n_bulk, n_peel = metal_bulk_peel_partition(z, electrons)
    peel = abs(metallic_peel_surplus_dimless(n_bulk, n_peel))
    merge = abs(metallic_valence_merge_surplus_dimless(z))
    surplus = max(peel, merge * 0.5)
    lattice_factor = metallic_lattice_contact_weight(sep)
    n_coord = max(coordination if coordination is not None else metallic_coordination(z), 1)
    coord_dress = 1.0 + strong_channel_fraction() / float(n_coord)
    e = electrons if electrons is not None else z
    valence_frac = n_bulk / max(e, 1)
    return surplus * lattice_factor * coord_dress * valence_frac


def metallic_lattice_contact_lock(
    z: int,
    *,
    separation_over_contact_radius: float,
    coordination: int | None = None,
) -> float:
    bind = metallic_lattice_binding_dimless_per_contact(
        z,
        separation_over_contact_radius=separation_over_contact_radius,
        coordination=coordination,
    )
    n_bulk, n_peel = metal_bulk_peel_partition(z)
    ref = max(abs(metallic_peel_surplus_dimless(n_bulk, n_peel)), surplus_reference_floor())
    return min(1.0, bind / ref)


def metallic_melt_density_ratio(
    z: int,
    *,
    separation_over_contact_radius: float | None = None,
    coordination: int | None = None,
) -> float:
    sep = (
        separation_over_contact_radius
        if separation_over_contact_radius is not None
        else metallic_nearest_neighbor_separation_dimless(z)
    )
    n_coord = coordination if coordination is not None else metallic_coordination(z)
    dw = metallic_lattice_contact_weight(sep)
    lock = metallic_lattice_contact_lock(z, separation_over_contact_radius=sep, coordination=n_coord)
    return metallic_melt_density_ratio_from_weights(dw, lock, n_coord)
