"""
Ionic contact slot on the curvature contact network.

Lean:
  • ``Hqiv/Geometry/BondedHorizonCasimir.ionicBondSurplus``
  • ``Hqiv/QuantumChemistry/IonicContactSlot.lean``
"""

from __future__ import annotations

from pyhqiv.bonded_horizon_casimir import ionic_bond_surplus_dimless
from pyhqiv.chemistry.contact_geometry import (
    dynamic_contact_radius_dimless,
    horizon_contact_weight,
)
from pyhqiv.chemistry.electronic_chart import electronic_compton_shells

__all__ = [
    "ionic_bond_surplus_dimless",
    "ionic_lattice_binding_dimless_per_contact",
    "ionic_lattice_contact_weight",
]


def ionic_lattice_contact_weight(separation_over_contact_radius: float) -> float:
    return horizon_contact_weight(separation_over_contact_radius)


def ionic_lattice_binding_dimless_per_contact(
    n_cation: int,
    n_anion: int,
    *,
    z_cation: int,
    z_anion: int,
    separation_over_contact_radius: float,
) -> float:
    """
    Lattice contact binding: ``|ionicBondSurplus| × lattice_factor × ionic_dress``.

    All quantities dimensionless on the λ / ``R_m`` ladder.
    """
    surplus = abs(ionic_bond_surplus_dimless(n_cation, n_anion))
    lattice_factor = ionic_lattice_contact_weight(separation_over_contact_radius)
    z_vals = [z_cation, z_anion]
    delta_z = max(z_vals) - min(z_vals)
    z_total = sum(z_vals)
    ionic_dress = 1.0 + (delta_z / max(z_total, 1)) * lattice_factor
    return surplus * ionic_dress


def ionic_separation_over_contact_radius(
    z_cation: int,
    z_anion: int,
    *,
    bond_ladder_separation: float,
) -> float:
    """``d/r_contact`` using the heavier centre Compton shell."""
    z_heavy = max(z_cation, z_anion)
    m_s, _ = electronic_compton_shells(z_heavy)
    r_contact = dynamic_contact_radius_dimless(m_s, z_heavy)
    if r_contact <= 0:
        return bond_ladder_separation
    return bond_ladder_separation / r_contact
