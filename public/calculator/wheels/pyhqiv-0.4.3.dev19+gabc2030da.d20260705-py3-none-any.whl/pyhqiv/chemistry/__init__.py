"""
Quantum-chemistry Lean mirrors (contact slots, electronic chart, bond geometry).

Dimensionless src only: λ-surplus, ``R_m/Z`` contacts, ``α/γ`` melt slots.
Translation layers (element symbols → Z, default isotope (P,N)) live in ``pyhqiv.nuclear``.
"""

from pyhqiv.chemistry.contact_geometry import (
    constructive_valley_cap,
    dynamic_contact_radius_dimless,
    horizon_contact_weight,
    strong_channel_fraction,
)
from pyhqiv.chemistry.electronic_chart import (
    chemical_period,
    electronic_compton_shells,
    tuft_heavy_chart_shell,
    tuft_strong_chart_shell,
    valence_electron_count,
)
from pyhqiv.bonded_horizon_casimir import ionic_bond_surplus_dimless, metallic_peel_surplus_dimless
from pyhqiv.chemistry.ionic_contact import (
    ionic_lattice_binding_dimless_per_contact,
    ionic_lattice_contact_weight,
)
from pyhqiv.chemistry.metallic_contact import (
    homonuclear_bond_equilibrium_dimless,
    is_metallic_element,
    metallic_coordination,
    metallic_lattice_binding_dimless_per_contact,
    metallic_lattice_contact_weight,
    metallic_melt_density_ratio,
    metallic_nearest_neighbor_separation_dimless,
    metallic_valence_merge_surplus_dimless,
)

__all__ = [
    "chemical_period",
    "constructive_valley_cap",
    "dynamic_contact_radius_dimless",
    "electronic_compton_shells",
    "homonuclear_bond_equilibrium_dimless",
    "horizon_contact_weight",
    "ionic_bond_surplus_dimless",
    "ionic_lattice_binding_dimless_per_contact",
    "ionic_lattice_contact_weight",
    "is_metallic_element",
    "metallic_coordination",
    "metallic_lattice_binding_dimless_per_contact",
    "metallic_lattice_contact_weight",
    "metallic_melt_density_ratio",
    "metallic_nearest_neighbor_separation_dimless",
    "metallic_peel_surplus_dimless",
    "metallic_valence_merge_surplus_dimless",
    "strong_channel_fraction",
    "tuft_heavy_chart_shell",
    "tuft_strong_chart_shell",
    "valence_electron_count",
]
